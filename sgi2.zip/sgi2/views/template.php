<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <link rel="shortcut icon" href="public/img/icon.png">
    <link rel="stylesheet" href="public/css/style.css">
    <title>SGI</title>
</head>

<body>
    <!-- Cabeçalho -->
    <header>

        <nav class="menu">
            <img src="public/img/logo.png" alt="logo" id="logo">
            <ul>
                <li></li>
            </ul>
        </nav>
    </header>
    <?php

    $this->carregarViewNoTemplate($nomeView, $this->dados);

    ?>




</body>

</html>