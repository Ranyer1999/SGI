<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <!-- Cabeçalho -->
    <header>
        <img src="public/img/sgi.png" alt="logo" id="logo">
        <nav class="menu">
            <ul>
                <li></li>
            </ul>
        </nav>
    </header>
    <?php

    $this->carregarViewNoTemplate($nomeView, $this->dados);

    ?>




</body>

</html>