<?php
class homeController extends controller
{

    public function index()
    {

        $this->carregarTemplate('home');
    }


    public $dados;

    public function __construct()
    {
        $this->dados = array();
    }

    public function carregarTemplate($nomeView, $dadosModel = array())
    {
        $this->dados = $dadosModel;
        require 'views/template.php';
    }

    public function carregarViewNoTemplate($nomeView, $dadosModel = array())
    {
        extract($dadosModel);
        require 'views/' . $nomeView . '.php';
    }
}
