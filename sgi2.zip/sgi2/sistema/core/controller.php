<?php

class controller
{
    public $dados;

    public function __construct()
    {
        $this->dados = array();
    }

    public function carregarTemplate($nomeView, $dadosModel = array())
    {
        $this->dados = $dadosModel;
    }

    public function carregarView($nomeView, $dadosModel = array()) {}
}