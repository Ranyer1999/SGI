<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['perfil'] !== 'Coordenacao') {
    header("Location: /sgi/index.php");
    exit;
}

$erro = '';
$sucesso = '';

// Função para validar a força da senha
function validarSenha($senha)
{
    // Verificar se tem pelo menos uma letra maiúscula
    if (!preg_match('/[A-Z]/', $senha)) {
        return "A senha deve conter pelo menos uma letra maiúscula";
    }

    // Verificar se tem pelo menos um número
    if (!preg_match('/[0-9]/', $senha)) {
        return "A senha deve conter pelo menos um número";
    }

    // Verificar se tem pelo menos um caractere especial
    if (!preg_match('/[^a-zA-Z0-9]/', $senha)) {
        return "A senha deve conter pelo menos um caractere especial";
    }

    // Verificar comprimento mínimo
    if (strlen($senha) < 6) {
        return "A senha deve ter pelo menos 6 caracteres";
    }

    return true;
}

// Função para validar CPF
function validarCPF($cpf)
{
    // Remove caracteres não numéricos
    $cpf = preg_replace('/[^0-9]/', '', $cpf);

    // Verifica se foi informado todos os digitos
    if (strlen($cpf) != 11) {
        return false;
    }

    // Verifica se foi informada uma sequência de digitos repetidos
    if (preg_match('/(\d)\1{10}/', $cpf)) {
        return false;
    }

    // Faz o cálculo para validar o CPF
    for ($t = 9; $t < 11; $t++) {
        for ($d = 0, $c = 0; $c < $t; $c++) {
            $d += $cpf[$c] * (($t + 1) - $c);
        }
        $d = ((10 * $d) % 11) % 10;
        if ($cpf[$c] != $d) {
            return false;
        }
    }
    return true;
}

// Função para validar telefone
function validarTelefone($telefone)
{
    // Remove caracteres não numéricos
    $telefone = preg_replace('/[^0-9]/', '', $telefone);

    // Verifica se é um telefone válido (10 ou 11 dígitos)
    if (strlen($telefone) < 10 || strlen($telefone) > 11) {
        return false;
    }

    return true;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $host = "localhost";
    $dbname = "sgi";
    $username = "root";
    $password = "";

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $nome_prof = $_POST["nome_prof"];
        $cpf = $_POST["cpf"];
        $telefone = $_POST["telefone"];
        $dt_nascimento = $_POST["dt_nascimento"];
        $email_prof = $_POST["email_prof"];
        $senha_prof = $_POST["senha_prof"];

        // Validar CPF
        if (!validarCPF($cpf)) {
            $erro = "CPF inválido.";
        }
        // Validar telefone
        else if (!validarTelefone($telefone)) {
            $erro = "Telefone inválido.";
        }
        // Validar a senha
        else {
            $validacaoSenha = validarSenha($senha_prof);
            if ($validacaoSenha !== true) {
                $erro = $validacaoSenha;
            } else {
                // Verificar se o email já existe
                $stmtVerifica = $pdo->prepare("SELECT idusuario FROM usuario WHERE user_login = ?");
                $stmtVerifica->execute([$email_prof]);

                if ($stmtVerifica->fetch()) {
                    $erro = "Este email já está cadastrado no sistema.";
                } else {
                    // Verificar si o CPF já existe
                    $stmtVerificaCPF = $pdo->prepare("SELECT idprofessor FROM professor WHERE cpf = ?");
                    $stmtVerificaCPF->execute([preg_replace('/[^0-9]/', '', $cpf)]);

                    if ($stmtVerificaCPF->fetch()) {
                        $erro = "Este CPF já está cadastrado no sistema.";
                    } else {
                        // CORREÇÃO: Remover a subconsulta problemática
                        // Buscar o ID do grupo de professores usando JOIN
                        $stmtGrupo = $pdo->prepare("
                            SELECT idgrupo_acesso 
                            FROM grupo_acesso 
                            WHERE nome_grupo = 'Professores'
                        ");
                        $stmtGrupo->execute();
                        $grupo = $stmtGrupo->fetch(PDO::FETCH_ASSOC);

                        if (!$grupo) {
                            $erro = "Grupo de acesso 'Professores' não encontrado.";
                        } else {
                            $idGrupo = $grupo['idgrupo_acesso'];

                            // Primeiro, criar um usuário para o professor
                            $stmtUsuario = $pdo->prepare("
                                INSERT INTO usuario (idgrupo_acesso, user_login, senha, dt_criacao) 
                                VALUES (?, ?, ?, NOW())
                            ");
                            $stmtUsuario->execute([$idGrupo, $email_prof, $senha_prof]);
                            $idUsuario = $pdo->lastInsertId();

                            // Inserir o professor
                            $stmtProfessor = $pdo->prepare("
                                INSERT INTO professor (nome_prof, cpf, telefone, dt_nascimento, email_prof, idusuario) 
                                VALUES (?, ?, ?, ?, ?, ?)
                            ");
                            $stmtProfessor->execute([
                                $nome_prof,
                                preg_replace('/[^0-9]/', '', $cpf),
                                preg_replace('/[^0-9]/', '', $telefone),
                                $dt_nascimento,
                                $email_prof,
                                $idUsuario
                            ]);
                            $idProfessor = $pdo->lastInsertId();

                            $sucesso = "Professor cadastrado com sucesso!";
                        }
                    }
                }
            }
        }
    } catch (PDOException $e) {
        $erro = "Erro ao cadastrar professor: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Cadastro de Professor</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }

        h1 {
            color: #2c3e50;
            text-align: center;
        }

        form {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        div {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"],
        input[type="date"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #3498db;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            background-color: #2980b9;
        }

        .erro {
            color: #e74c3c;
            background-color: #fadbd8;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
        }

        .sucesso {
            color: #27ae60;
            background-color: #d5f4e6;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
        }

        .requisitos-senha {
            font-size: 12px;
            color: #7f8c8d;
            margin-top: 5px;
        }

        a {
            color: #3498db;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        .campo-invalido {
            border-color: #e74c3c !important;
            background-color: #fadbd8;
        }

        .mensagem-erro {
            color: #e74c3c;
            font-size: 12px;
            margin-top: 5px;
        }
    </style>
</head>

<body>
    <h1>Cadastro Docente</h1>
    <a href=" /sgi/views/listarDocentes.php">Voltar</a>

    <?php if (!empty($erro)): ?>
        <div class="erro"><?php echo $erro; ?></div>
    <?php endif; ?>

    <?php if (!empty($sucesso)): ?>
        <div class="sucesso"><?php echo $sucesso; ?></div>
    <?php endif; ?>

    <form method="post" id="formCadastro">
        <div>
            <label for="nome_prof">Nome Completo:</label>
            <input type="text" id="nome_prof" name="nome_prof" required>
        </div>

        <div>
            <label for="cpf">CPF:</label>
            <input type="text" id="cpf" name="cpf" placeholder="000.000.000-00" required maxlength="14">
            <div id="cpfErro" class="mensagem-erro"></div>
        </div>

        <div>
            <label for="telefone">Telefone:</label>
            <input type="text" id="telefone" name="telefone" placeholder="(00) 00000-0000" required maxlength="15">
            <div id="telefoneErro" class="mensagem-erro"></div>
        </div>

        <div>
            <label for="dt_nascimento">Data de Nascimento:</label>
            <input type="date" id="dt_nascimento" name="dt_nascimento" required>
        </div>

        <div>
            <label for="email_prof">Email:</label>
            <input type="email" id="email_prof" name="email_prof" required>
        </div>

        <div>
            <label for="senha_prof">Senha:</label>
            <input type="password" id="senha_prof" name="senha_prof" required minlength="6">
            <div class="requisitos-senha">
                A senha deve conter pelo menos:
                <ul>
                    <li id="req1">6 caracteres</li>
                    <li id="req2">1 letra maiúscula</li>
                    <li id="req3">1 número</li>
                    <li id="req4">1 caractere especial (ex: @, #, $, etc.)</li>
                </ul>
            </div>
        </div>

        <input type="submit" value="Cadastrar Professor">
    </form>

    <script>
        // Aplicar máscara ao CPF
        function mascaraCPF(cpf) {
            cpf = cpf.replace(/\D/g, "");
            cpf = cpf.replace(/(\d{3})(\d)/, "$1.$2");
            cpf = cpf.replace(/(\d{3})(\d)/, "$1.$2");
            cpf = cpf.replace(/(\d{3})(\d{1,2})$/, "$1-$2");
            return cpf;
        }

        // Aplicar máscara ao telefone
        function mascaraTelefone(telefone) {
            telefone = telefone.replace(/\D/g, "");
            telefone = telefone.replace(/^(\d{2})(\d)/g, "($1) $2");
            telefone = telefone.replace(/(\d)(\d{4})$/, "$1-$2");
            return telefone;
        }

        // Validar CPF com algoritmo
        function validarCPF(cpf) {
            cpf = cpf.replace(/\D/g, '');

            if (cpf.length !== 11) return false;

            // Verifica se todos os dígitos são iguais
            if (/^(\d)\1+$/.test(cpf)) return false;

            // Validação do algoritmo do CPF
            let soma = 0;
            let resto;

            for (let i = 1; i <= 9; i++)
                soma += parseInt(cpf.substring(i - 1, i)) * (11 - i);
            resto = (soma * 10) % 11;

            if ((resto === 10) || (resto === 11)) resto = 0;
            if (resto !== parseInt(cpf.substring(9, 10))) return false;

            soma = 0;
            for (let i = 1; i <= 10; i++)
                soma += parseInt(cpf.substring(i - 1, i)) * (12 - i);
            resto = (soma * 10) % 11;

            if ((resto === 10) || (resto === 11)) resto = 0;
            if (resto !== parseInt(cpf.substring(10, 11))) return false;

            return true;
        }

        // Validar telefone
        function validarTelefone(telefone) {
            telefone = telefone.replace(/\D/g, '');
            return telefone.length >= 10 && telefone.length <= 11;
        }

        // Elementos do DOM
        const cpfInput = document.getElementById('cpf');
        const telefoneInput = document.getElementById('telefone');
        const cpfErro = document.getElementById('cpfErro');
        const telefoneErro = document.getElementById('telefoneErro');
        const form = document.getElementById('formCadastro');

        // Aplicar máscaras durante a digitação
        cpfInput.addEventListener('input', function() {
            this.value = mascaraCPF(this.value);

            // Validar em tempo real
            if (this.value.length === 14) {
                if (validarCPF(this.value)) {
                    this.classList.remove('campo-invalido');
                    cpfErro.textContent = '';
                } else {
                    this.classList.add('campo-invalido');
                    cpfErro.textContent = 'CPF inválido';
                }
            } else {
                this.classList.remove('campo-invalido');
                cpfErro.textContent = '';
            }
        });

        telefoneInput.addEventListener('input', function() {
            this.value = mascaraTelefone(this.value);

            // Validar em tempo real
            if (this.value.length === 15) {
                if (validarTelefone(this.value)) {
                    this.classList.remove('campo-invalido');
                    telefoneErro.textContent = '';
                } else {
                    this.classList.add('campo-invalido');
                    telefoneErro.textContent = 'Telefone inválido';
                }
            } else {
                this.classList.remove('campo-invalido');
                telefoneErro.textContent = '';
            }
        });

        // Validação antes do envio do formulário
        form.addEventListener('submit', function(e) {
            let cpfValido = validarCPF(cpfInput.value);
            let telefoneValido = validarTelefone(telefoneInput.value);

            if (!cpfValido) {
                e.preventDefault();
                cpfInput.classList.add('campo-invalido');
                cpfErro.textContent = 'CPF inválido';
            }

            if (!telefoneValido) {
                e.preventDefault();
                telefoneInput.classList.add('campo-invalido');
                telefoneErro.textContent = 'Telefone inválido';
            }
        });

        // Validação em tempo real da senha
        document.getElementById('senha_prof').addEventListener('input', function() {
            const senha = this.value;
            const requisitos = {
                maiuscula: /[A-Z]/.test(senha),
                numero: /[0-9]/.test(senha),
                especial: /[^a-zA-Z0-9]/.test(senha),
                comprimento: senha.length >= 6
            };

            // Atualizar visualmente os requisitos
            document.getElementById('req1').style.color = requisitos.comprimento ? 'green' : 'red';
            document.getElementById('req2').style.color = requisitos.maiuscula ? 'green' : 'red';
            document.getElementById('req3').style.color = requisitos.numero ? 'green' : 'red';
            document.getElementById('req4').style.color = requisitos.especial ? 'green' : 'red';
        });
    </script>
</body>

</html>