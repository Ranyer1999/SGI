<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['perfil'] !== 'Coordenacao') {
    header("Location: /sgi/index.php");
    exit;
}

$host = "localhost";
$dbname = "sgi";
$username = "root";
$password = "";

$filtro_status = $_GET['status'] ?? '';
$filtro_professor = $_GET['professor'] ?? '';
$filtro_turma = $_GET['turma'] ?? '';
$filtro_componente = $_GET['componente'] ?? '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Construir a query base com filtros
    $sql = "
        SELECT 
            a.idalocacao,
            a.dt_alocacao,
            a.periodo_inicio,
            a.periodo_fim,
            p.idprofessor,
            p.nome_prof,
            t.idturma,
            t.nome_turma,
            c.nome_curso,
            comp.nome_componente,
            comp.cargahr_comp,
            s.nome_stalocacao as status_alocacao
        FROM alocacao a
        JOIN professor p ON a.idprofessor = p.idprofessor
        JOIN turma t ON a.idturma = t.idturma
        JOIN curso c ON t.idcurso = c.idcurso
        JOIN componente comp ON a.idcomponente = comp.idcomponente
        JOIN status_alocacao s ON a.idstatus_alocacao = s.idstatus_alocacao
        WHERE 1=1
    ";

    $params = [];

    if (!empty($filtro_status)) {
        $sql .= " AND s.nome_stalocacao = ?";
        $params[] = $filtro_status;
    }

    if (!empty($filtro_professor)) {
        $sql .= " AND p.nome_prof LIKE ?";
        $params[] = "%$filtro_professor%";
    }

    if (!empty($filtro_turma)) {
        $sql .= " AND t.nome_turma LIKE ?";
        $params[] = "%$filtro_turma%";
    }

    if (!empty($filtro_componente)) {
        $sql .= " AND comp.nome_componente LIKE ?";
        $params[] = "%$filtro_componente%";
    }

    $sql .= " ORDER BY a.dt_alocacao DESC, p.nome_prof";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $alocacoes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Buscar status para o filtro
    $stmtStatus = $pdo->prepare("SELECT DISTINCT nome_stalocacao FROM status_alocacao ORDER BY nome_stalocacao");
    $stmtStatus->execute();
    $status_lista = $stmtStatus->fetchAll(PDO::FETCH_COLUMN);

    // Buscar componentes para o filtro
    $stmtComponentes = $pdo->prepare("SELECT DISTINCT nome_componente FROM componente ORDER BY nome_componente");
    $stmtComponentes->execute();
    $componentes_lista = $stmtComponentes->fetchAll(PDO::FETCH_COLUMN);

} catch (PDOException $e) {
    $erro = "Erro ao carregar alocações: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Lista de Alocações</title>
</head>
<body>
    <h1>Alocações dos Docentes</h1>

    <a href="homeCoordenacao.php">Voltar para Home</a>
    <a href="cadastrarAlocacoes.php">Nova Alocação</a>

    <?php if (isset($erro)): ?>
        <div style="color: red; background-color: #fadbd8; padding: 10px; border-radius: 4px; margin-bottom: 15px;">
            <?php echo $erro; ?>
        </div>
    <?php endif; ?>

    <div>
        <h3>Filtrar Alocações</h3>
        <form method="get">
            <div>
                <label for="status">Status:</label>
                <select id="status" name="status">
                    <option value="">Todos os status</option>
                    <?php foreach ($status_lista as $status): ?>
                        <option value="<?php echo $status; ?>" <?php echo $filtro_status === $status ? 'selected' : ''; ?>>
                            <?php echo $status; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label for="professor">Professor:</label>
                <input type="text" id="professor" name="professor"
                    value="<?php echo htmlspecialchars($filtro_professor); ?>" placeholder="Nome do professor">
            </div>

            <div>
                <label for="turma">Turma:</label>
                <input type="text" id="turma" name="turma" value="<?php echo htmlspecialchars($filtro_turma); ?>"
                    placeholder="Nome da turma">
            </div>

            <div>
                <label for="componente">Componente:</label>
                <input type="text" id="componente" name="componente" value="<?php echo htmlspecialchars($filtro_componente); ?>"
                    placeholder="Nome do componente">
            </div>

            <div>
                <input type="submit" value="Filtrar">
            </div>
        </form>

        <?php if ($filtro_status || $filtro_professor || $filtro_turma || $filtro_componente): ?>
            <a href="listarAlocacoes.php">Limpar Filtros</a>
        <?php endif; ?>
    </div>

    <?php if (count($alocacoes) > 0): ?>
        <table border="1">
            <thead>
                <tr>
                    <th>Professor</th>
                    <th>Turma</th>
                    <th>Curso</th>
                    <th>Componente</th>
                    <th>Carga Horária</th>
                    <th>Data Alocação</th>
                    <th>Período</th>
                    <th>Status</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($alocacoes as $alocacao): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($alocacao['nome_prof']); ?></td>
                        <td><?php echo htmlspecialchars($alocacao['nome_turma']); ?></td>
                        <td><?php echo htmlspecialchars($alocacao['nome_curso']); ?></td>
                        <td><?php echo htmlspecialchars($alocacao['nome_componente']); ?></td>
                        <td><?php echo $alocacao['cargahr_comp']; ?>h</td>
                        <td><?php echo date('d/m/Y', strtotime($alocacao['dt_alocacao'])); ?></td>
                        <td>
                            <?php echo date('d/m/Y', strtotime($alocacao['periodo_inicio'])); ?>
                            a
                            <?php echo date('d/m/Y', strtotime($alocacao['periodo_fim'])); ?>
                        </td>
                        <td>
                            <?php
                            if ($alocacao['status_alocacao'] === 'Ativa') {
                                echo '<span style="color: green; font-weight: bold;">Ativa</span>';
                            } elseif ($alocacao['status_alocacao'] === 'Encerrada') {
                                echo '<span style="color: orange;">Encerrada</span>';
                            } elseif ($alocacao['status_alocacao'] === 'Cancelada') {
                                echo '<span style="color: red;">Cancelada</span>';
                            } else {
                                echo htmlspecialchars($alocacao['status_alocacao']);
                            }
                            ?>
                        </td>
                        <td>
                            <a href="../crud_operations/editarAlocacao.php?id=<?php echo $alocacao['idalocacao']; ?>">Editar</a>
                            <a href="../crud_operations/excluirAlocacao.php?id=<?php echo $alocacao['idalocacao']; ?>"
                                onclick="return confirm('Tem certeza que deseja excluir esta alocação?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <div>
            <h3>Nenhuma alocação encontrada</h3>
            <p><?php echo ($filtro_status || $filtro_professor || $filtro_turma || $filtro_componente) ? 'Tente ajustar os filtros.' : 'Cadastre a primeira alocação.'; ?>
            </p>
        </div>
    <?php endif; ?>
</body>
</html>