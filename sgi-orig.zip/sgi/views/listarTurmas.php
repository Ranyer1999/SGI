<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['perfil'] !== 'Coordenacao') {
    header("Location: /sgi/index.php");
    exit;
}

$host = "localhost";
$dbname = "sgi";
$username = "root";
$password = "";

// Parâmetros de filtro
$filtro_turma = $_GET['turma'] ?? '';
$filtro_curso = $_GET['curso'] ?? '';
$filtro_status = $_GET['status'] ?? '';
$filtro_turno = $_GET['turno'] ?? '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Construir query com filtros
    $sql = "
        SELECT 
            t.*,
            c.nome_curso,
            tu.nome_turno,
            st.nome_stturma,
            g.dt_vigencia
        FROM turma t
        JOIN curso c ON t.idcurso = c.idcurso
        JOIN turno tu ON t.idturno = tu.idturno
        JOIN status_turma st ON t.idstatus_turma = st.idstatus_turma
        JOIN grade_curricular g ON t.idgrade_curricular = g.idgrade_curricular
        WHERE 1=1
    ";
    
    $params = [];

    if (!empty($filtro_turma)) {
        $sql .= " AND t.nome_turma LIKE ?";
        $params[] = "%$filtro_turma%";
    }

    if (!empty($filtro_curso)) {
        $sql .= " AND c.nome_curso LIKE ?";
        $params[] = "%$filtro_curso%";
    }

    if (!empty($filtro_status)) {
        $sql .= " AND st.nome_stturma = ?";
        $params[] = $filtro_status;
    }

    if (!empty($filtro_turno)) {
        $sql .= " AND tu.nome_turno = ?";
        $params[] = $filtro_turno;
    }

    $sql .= " ORDER BY t.dt_inicio DESC, t.nome_turma";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $turmas = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Buscar status para o filtro
    $stmtStatus = $pdo->prepare("SELECT nome_stturma FROM status_turma");
    $stmtStatus->execute();
    $status_lista = $stmtStatus->fetchAll(PDO::FETCH_COLUMN);

    // Buscar turnos para o filtro
    $stmtTurnos = $pdo->prepare("SELECT nome_turno FROM turno");
    $stmtTurnos->execute();
    $turnos_lista = $stmtTurnos->fetchAll(PDO::FETCH_COLUMN);

} catch (PDOException $e) {
    $erro = "Erro ao carregar turmas: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Lista de Turmas</title>
</head>

<body>
    <h1>Turmas Cadastradas</h1>
    <a href="/sgi/views/homeCoordenacao.php">Voltar para Home</a>
    <a href="/sgi/views/cadastrarTurmas.php">Cadastrar nova Turma</a>

    <?php if (isset($erro)): ?>
        <div><?php echo $erro; ?></div>
    <?php endif; ?>

    <!-- Formulário de Filtro -->
    <div style="margin: 20px 0; padding: 15px; border: 1px solid #ddd; background-color: #f9f9f9;">
        <h3>Filtrar Turmas</h3>
        <form method="get">
            <div>
                <label for="turma">Nome da Turma:</label>
                <input type="text" id="turma" name="turma" value="<?php echo htmlspecialchars($filtro_turma); ?>" placeholder="Nome da turma">
            </div>

            <div>
                <label for="curso">Curso:</label>
                <input type="text" id="curso" name="curso" value="<?php echo htmlspecialchars($filtro_curso); ?>" placeholder="Nome do curso">
            </div>

            <div>
                <label for="status">Status:</label>
                <select id="status" name="status">
                    <option value="">Todos os status</option>
                    <?php foreach ($status_lista as $status): ?>
                        <option value="<?php echo $status; ?>" <?php echo $filtro_status === $status ? 'selected' : ''; ?>>
                            <?php echo $status; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label for="turno">Turno:</label>
                <select id="turno" name="turno">
                    <option value="">Todos os turnos</option>
                    <?php foreach ($turnos_lista as $turno): ?>
                        <option value="<?php echo $turno; ?>" <?php echo $filtro_turno === $turno ? 'selected' : ''; ?>>
                            <?php echo $turno; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <input type="submit" value="Filtrar">
                <?php if ($filtro_turma || $filtro_curso || $filtro_status || $filtro_turno): ?>
                    <a href="listarTurmas.php" style="margin-left: 10px;">Limpar Filtros</a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <?php if (count($turmas) > 0): ?>
        <table border="1" style="width: 100%; border-collapse: collapse;">
            <thead>
                <tr>
                    <th>Nome da Turma</th>
                    <th>Curso</th>
                    <th>Data Início</th>
                    <th>Data Fim</th>
                    <th>Turno</th>
                    <th>Status</th>
                    <th>Vigência da Grade</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($turmas as $turma): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($turma['nome_turma']); ?></td>
                        <td><?php echo htmlspecialchars($turma['nome_curso']); ?></td>
                        <td><?php echo date('d/m/Y', strtotime($turma['dt_inicio'])); ?></td>
                        <td><?php echo date('d/m/Y', strtotime($turma['dt_fim'])); ?></td>
                        <td><?php echo htmlspecialchars($turma['nome_turno']); ?></td>
                        <td><?php echo htmlspecialchars($turma['nome_stturma']); ?></td>
                        <td><?php echo date('d/m/Y', strtotime($turma['dt_vigencia'])); ?></td>
                        <td>
                            <a href="../crud_operations/editarTurma.php?id=<?php echo $turma['idturma']; ?>">Editar</a>
                            <a href="../crud_operations/excluirTurma.php?id=<?php echo $turma['idturma']; ?>"
                                onclick="return confirm('Tem certeza que deseja excluir esta turma?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Nenhuma turma encontrada <?php echo ($filtro_turma || $filtro_curso || $filtro_status || $filtro_turno) ? 'com os filtros aplicados' : 'cadastrada'; ?>.</p>
    <?php endif; ?>
</body>

</html>