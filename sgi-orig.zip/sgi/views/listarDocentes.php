<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['perfil'] !== 'Coordenacao') {
    header("Location: login.php");
    exit;
}

$host = "localhost";
$dbname = "sgi";
$username = "root";
$password = "";

// Parâmetros de filtro
$filtro_nome = $_GET['nome'] ?? '';
$filtro_email = $_GET['email'] ?? '';
$filtro_cpf = $_GET['cpf'] ?? '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Construir query com filtros
    $sql = "SELECT * FROM professor WHERE 1=1";
    $params = [];

    if (!empty($filtro_nome)) {
        $sql .= " AND nome_prof LIKE ?";
        $params[] = "%$filtro_nome%";
    }

    if (!empty($filtro_email)) {
        $sql .= " AND email_prof LIKE ?";
        $params[] = "%$filtro_email%";
    }

    if (!empty($filtro_cpf)) {
        $sql .= " AND cpf LIKE ?";
        $params[] = "%$filtro_cpf%";
    }

    $sql .= " ORDER BY nome_prof";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $professores = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $erro = "Erro ao carregar professores: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Docentes Cadastrados</title>
</head>

<body>
    <h1>Docentes Cadastrados</h1>
    <a href="/sgi/views/homeCoordenacao.php">Voltar para Home</a>
    <a href="/sgi/views/cadastrarDocentes.php">Cadastrar novo Docente</a>

    <?php if (isset($erro)): ?>
        <div><?php echo $erro; ?></div>
    <?php endif; ?>

    <!-- Formulário de Filtro -->
    <div style="margin: 20px 0; padding: 15px; border: 1px solid #ddd; background-color: #f9f9f9;">
        <h3>Filtrar Docentes</h3>
        <form method="get">
            <div>
                <label for="nome">Nome:</label>
                <input type="text" id="nome" name="nome" value="<?php echo htmlspecialchars($filtro_nome); ?>" placeholder="Nome do professor">
            </div>

            <div>
                <label for="email">Email:</label>
                <input type="text" id="email" name="email" value="<?php echo htmlspecialchars($filtro_email); ?>" placeholder="Email do professor">
            </div>

            <div>
                <label for="cpf">CPF:</label>
                <input type="text" id="cpf" name="cpf" value="<?php echo htmlspecialchars($filtro_cpf); ?>" placeholder="CPF do professor">
            </div>

            <div>
                <input type="submit" value="Filtrar">
                <?php if ($filtro_nome || $filtro_email || $filtro_cpf): ?>
                    <a href="listarDocentes.php" style="margin-left: 10px;">Limpar Filtros</a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <?php if (count($professores) > 0): ?>
        <table border="1" style="width: 100%; border-collapse: collapse;">
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>Email</th>
                    <th>CPF</th>
                    <th>Telefone</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($professores as $professor): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($professor['nome_prof']); ?></td>
                        <td><?php echo htmlspecialchars($professor['email_prof']); ?></td>
                        <td><?php echo htmlspecialchars($professor['cpf']); ?></td>
                        <td><?php echo htmlspecialchars($professor['telefone']); ?></td>
                        <td>
                            <a href="/sgi/views/verDocente.php?id=<?php echo $professor['idprofessor']; ?>">Ver</a>
                            <a href="/sgi/views/editarDocente.php?id=<?php echo $professor['idprofessor']; ?>">Editar</a>
                            <a href="/sgi/views/excluirDocente.php?id=<?php echo $professor['idprofessor']; ?>"
                                onclick="return confirm('Tem certeza que deseja excluir este docente?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Nenhum docente encontrado <?php echo ($filtro_nome || $filtro_email || $filtro_cpf) ? 'com os filtros aplicados' : 'cadastrado'; ?>.</p>
    <?php endif; ?>
</body>

</html>