<?php
session_start();
// Permitir acesso tanto para coordenadores quanto para o próprio professor
if (!isset($_SESSION['usuario'])) {
    header("Location: ../index.php");
    exit;
}

if (!isset($_GET['id'])) {
    header("Location: ../listarDocentes.php");
    exit;
}

$idProfessor = $_GET['id'];
$host = "localhost";
        $dbname = "sgi";
        $username = "root";
        $password = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Buscar dados do professor
    $stmt = $pdo->prepare("SELECT * FROM professor WHERE idprofessor = ?");
    $stmt->execute([$idProfessor]);
    $professor = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$professor) {
        header("Location: ../listarDocentes.php");
        exit;
    }

    // Buscar formações do professor
    $stmtFormacoes = $pdo->prepare("SELECT * FROM formacao_professor WHERE idprofessor = ? ORDER BY ano_conclusao DESC");
    $stmtFormacoes->execute([$idProfessor]);
    $formacoes = $stmtFormacoes->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $erro = "Erro ao carregar perfil: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Perfil do Docente - <?php echo $professor['nome_prof']; ?></title>
</head>
<header>

    <nav class="menu">
        <img src="/sgi/public/img/logo.png" alt="logo" id="logo">
        <ul>
            <li id="sair"><button onclick="window.location.href='logout.php'">Sair</button></li>
        </ul>
    </nav>
</header>

<body>
    <h1>Perfil do Docente</h1>

    <?php if ($_SESSION['perfil'] === 'Coordenacao'): ?>

    <?php else: ?>

    <?php endif; ?>

    <?php if (isset($erro)): ?>
        <div><?php echo $erro; ?></div>
    <?php else: ?>
        <h2><?php echo $professor['nome_prof']; ?></h2>
        <p><strong>CPF:</strong> <?php echo $professor['cpf']; ?></p>
        <p><strong>Telefone:</strong> <?php echo $professor['telefone']; ?></p>
        <p><strong>Data de Nascimento:</strong> <?php echo date('d/m/Y', strtotime($professor['dt_nascimento'])); ?></p>
        <p><strong>Email:</strong> <?php echo $professor['email_prof']; ?></p>

        <h3>Formações</h3>
        <?php if (count($formacoes) > 0): ?>
            <ul>
                <?php foreach ($formacoes as $formacao): ?>
                    <li>
                        <strong><?php echo $formacao['nome_formacao']; ?></strong> -
                        <?php echo $formacao['tipo_formacao']; ?> -
                        <?php echo $formacao['instituicao']; ?> -
                        Conclusão: <?php echo $formacao['ano_conclusao']; ?> -
                        Carga Horária: <?php echo $formacao['cargahr_formacao']; ?> horas
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p>Nenhuma formação cadastrada.</p>
        <?php endif; ?>
        <!-- No loop das formações, adicione: -->
<?php if ($_SESSION['perfil'] === 'Coordenacao' || $_SESSION['id_usuario'] == $professor['idusuario']): ?>
    <div>
        <a href="../crud_operations/editarFormacao.php?id=<?php echo $formacao['idformacao']; ?>">Editar</a>
        <a href="../crud_operations/excluirFormacao.php?id=<?php echo $formacao['idformacao']; ?>" 
           onclick="return confirm('Tem certeza que deseja excluir esta formação?')">Excluir</a>
    </div>
<?php endif; ?>

        <!-- Adicione este código no perfilDocente.php -->
        <p>
            <a href="cadastrarFormacao.php?id=<?php echo $professor['idprofessor']; ?>">Adicionar Formação</a>
        </p>

        <?php if ($_SESSION['perfil'] === 'Coordenacao'): ?>
        <?php endif; ?>
    <?php endif; ?>

    

    <!-- Adicione este código no perfilDocente.php -->
    <?php if ($_SESSION['perfil'] === 'Professores'): ?>
        <p>
            <a href="minhasAlocacoes.php">Ver Minhas Alocações</a>
        </p>
    <?php endif; ?>
</body>

</html>