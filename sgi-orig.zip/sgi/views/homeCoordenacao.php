<?php
$action = $_GET['action'] ?? '';
$id     = $_GET['id'] ?? null;
$termo  = $_POST['termo'] ?? '';
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <link rel="shortcut icon" href="/sgi/public/img/icon.png">
    <meta charset="UTF-8">
    <link rel="stylesheet" href="/sgi/public/css/style.css">
    <title>SGI</title>
</head>
<header>

    <nav class="menu">
        <img src="/sgi/public/img/logo.png" alt="logo" id="logo">
        <ul>
            <li id="sair"><button onclick="window.location.href='logout.php'">Sair</button></li>
        </ul>
    </nav>
</header>

<body>
    <h2 id="h2-home">Home</h2>
    <form action="post" class="perfil-form">
        Coordenação
    </form>
    <form action="post" class="dados-form">

        <a href="listarTurmas.php">Turmas</a>
        <a href="listarDocentes.php">Docentes</a>
        <a href="listarAlocacoes.php">Alocações</a>
    </form>
</body>

</html>

<body>