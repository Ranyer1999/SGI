<?php
// logout.php
session_start();
session_destroy();
header("Location: /sgi/index.php");
exit;