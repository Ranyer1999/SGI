<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Gestão Institucional - Login</title>
</head>

<body>

    <?php
    session_start();
    $erro = "";

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $host = "localhost";
        $dbname = "sgi";
        $username = "root";
        $password = "";

        try {
            $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $email = $_POST["email"];
            $senha = $_POST["senha"];

            // Verificar se é um coordenador, professor ou administrador
            $stmt = $pdo->prepare("
            SELECT u.*, g.nome_grupo, 
                   CASE 
                     WHEN g.nome_grupo = 'Professores' THEN p.idprofessor
                     WHEN g.nome_grupo = 'Coordenacao' THEN c.idcoordenador
                     WHEN g.nome_grupo = 'Administradores' THEN a.idadmin
                   END as id_perfil
            FROM usuario u 
            JOIN grupo_acesso g ON u.idgrupo_acesso = g.idgrupo_acesso 
            LEFT JOIN professor p ON u.idusuario = p.idusuario AND g.nome_grupo = 'Professores'
            LEFT JOIN coordenador c ON u.idusuario = c.idusuario AND g.nome_grupo = 'Coordenacao'
            LEFT JOIN administrador a ON u.idusuario = a.idusuario AND g.nome_grupo = 'Administradores'
            WHERE u.user_login = ? AND u.senha = ? 
            AND (g.nome_grupo = 'Coordenacao' OR g.nome_grupo = 'Professores' OR g.nome_grupo = 'Administradores')
        ");
            $stmt->execute([$email, $senha]);
            $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($usuario) {
                $_SESSION["usuario"] = $usuario["user_login"];
                $_SESSION["perfil"] = $usuario["nome_grupo"];
                $_SESSION["id_usuario"] = $usuario["idusuario"];
                $_SESSION["id_perfil"] = $usuario["id_perfil"];

                // Redireciona conforme o perfil
                if ($usuario["nome_grupo"] === "Coordenacao") {
                    header("Location: views/homeCoordenacao.php");
                } else if ($usuario["nome_grupo"] === "Administradores") {
                    header("Location: homeAdmin.php");
                } else {
                    // Redireciona para o perfil do professor
                    header("Location:views/perfilDocente.php?id=" . $usuario["id_perfil"]);
                }
                exit;
            } else {
                $erro = "Email ou senha inválidos.";
            }
        } catch (PDOException $e) {
            $erro = "Erro de conexão: " . $e->getMessage();
        }
    }
    ?>

    <div class="container">
        <div class="bemvindo-panel">
            <img src="/sgi/public/img/sgi.png" alt="Logo SGI" class="logo-sgi">
            <h1>Bem-vindo ao SGI!</h1>
            <p>Tecnologia a serviço da educação</p>
        </div>

        <div class="login-panel">
            <div class="login-box">
                <h3>LOGIN</h3>

                <?php if (!empty($erro)): ?>
                    <div class="erro-messagem">
                        <?= htmlspecialchars($erro) ?>
                    </div>
                <?php endif; ?>

                <form method="post">
                    <div class="input-campo">
                        <label for="email">EMAIL:</label>
                        <input type="email" id="email" name="email" required>
                    </div>

                    <div class="input-campo">
                        <label for="senha">SENHA:</label>
                        <input type="password" id="senha" name="senha" required>
                    </div>

                    <button type="submit" class="button-acessar">ACESSAR</button>

                    <a href="/views/recuperarSenha.php" class="recuperar-senha">Recuperar senha</a>
                </form>
            </div>
        </div>
    </div>
</body>

</html>