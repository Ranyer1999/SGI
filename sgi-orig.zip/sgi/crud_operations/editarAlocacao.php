<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['perfil'] !== 'Coordenacao') {
    header("Location: /sgi/index.php");
    exit;
}

$host = "localhost";
$dbname = "sgi";
$username = "root";
$password = "";

$erro = '';
$sucesso = '';

if (!isset($_GET['id'])) {
    header("Location: ../listarAlocacoes.php");
    exit;
}

$idAlocacao = $_GET['id'];

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Buscar dados da alocação
    $stmtAlocacao = $pdo->prepare("
        SELECT a.*, p.nome_prof, t.nome_turma, c.nome_componente, s.nome_stalocacao
        FROM alocacao a
        JOIN professor p ON a.idprofessor = p.idprofessor
        JOIN turma t ON a.idturma = t.idturma
        JOIN componente c ON a.idcomponente = c.idcomponente
        JOIN status_alocacao s ON a.idstatus_alocacao = s.idstatus_alocacao
        WHERE a.idalocacao = ?
    ");
    $stmtAlocacao->execute([$idAlocacao]);
    $alocacao = $stmtAlocacao->fetch(PDO::FETCH_ASSOC);

    if (!$alocacao) {
        header("Location: ../listarAlocacoes.php");
        exit;
    }

    // Buscar dados para os selects
    $stmtProfessores = $pdo->prepare("SELECT idprofessor, nome_prof FROM professor ORDER BY nome_prof");
    $stmtProfessores->execute();
    $professores = $stmtProfessores->fetchAll(PDO::FETCH_ASSOC);

    $stmtTurmas = $pdo->prepare("
        SELECT t.idturma, t.nome_turma, c.nome_curso 
        FROM turma t
        JOIN curso c ON t.idcurso = c.idcurso
        WHERE t.idstatus_turma = (SELECT idstatus_turma FROM status_turma WHERE nome_stturma = 'Aberta')
        ORDER BY t.nome_turma
    ");
    $stmtTurmas->execute();
    $turmas = $stmtTurmas->fetchAll(PDO::FETCH_ASSOC);

    $stmtComponentes = $pdo->prepare("SELECT idcomponente, nome_componente FROM componente ORDER BY nome_componente");
    $stmtComponentes->execute();
    $componentes = $stmtComponentes->fetchAll(PDO::FETCH_ASSOC);

    $stmtStatus = $pdo->prepare("SELECT idstatus_alocacao, nome_stalocacao FROM status_alocacao");
    $stmtStatus->execute();
    $status_alocacoes = $stmtStatus->fetchAll(PDO::FETCH_ASSOC);

    // Processar o formulário
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $idprofessor = $_POST["idprofessor"];
        $idturma = $_POST["idturma"];
        $idcomponente = $_POST["idcomponente"];
        $idstatus_alocacao = $_POST["idstatus_alocacao"];
        $periodo_inicio = $_POST["periodo_inicio"];
        $periodo_fim = $_POST["periodo_fim"];

        // Validar datas
        if ($periodo_inicio >= $periodo_fim) {
            $erro = "A data de início deve ser anterior à data de fim.";
        } else {
            // Atualizar a alocação
            $stmt = $pdo->prepare("
                UPDATE alocacao 
                SET idprofessor = ?, idturma = ?, idcomponente = ?, 
                    idstatus_alocacao = ?, periodo_inicio = ?, periodo_fim = ?
                WHERE idalocacao = ?
            ");
            $stmt->execute([$idprofessor, $idturma, $idcomponente, $idstatus_alocacao, $periodo_inicio, $periodo_fim, $idAlocacao]);

            $sucesso = "Alocação atualizada com sucesso!";
            header("Refresh: 2; URL=../listarAlocacoes.php");
        }
    }

} catch (PDOException $e) {
    $erro = "Erro de conexão: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Alocação</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; }
        .erro { color: red; background-color: #fadbd8; padding: 10px; border-radius: 4px; }
        .sucesso { color: green; background-color: #d5f4e6; padding: 10px; border-radius: 4px; }
        form div { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        select, input { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; }
        input[type="submit"] { background-color: #3498db; color: white; padding: 10px 15px; border: none; border-radius: 4px; cursor: pointer; }
    </style>
</head>
<body>
    <h1>Editar Alocação</h1>
    <a href="../listarAlocacoes.php">Voltar para Lista</a>

    <?php if (!empty($erro)): ?>
        <div class="erro"><?php echo $erro; ?></div>
    <?php endif; ?>

    <?php if (!empty($sucesso)): ?>
        <div class="sucesso"><?php echo $sucesso; ?></div>
        <p>Redirecionando para a lista de alocações...</p>
    <?php else: ?>
        <form method="post">
            <div>
                <label for="idprofessor">Professor:</label>
                <select id="idprofessor" name="idprofessor" required>
                    <?php foreach ($professores as $professor): ?>
                        <option value="<?php echo $professor['idprofessor']; ?>" 
                            <?php echo $professor['idprofessor'] == $alocacao['idprofessor'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($professor['nome_prof']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label for="idturma">Turma:</label>
                <select id="idturma" name="idturma" required>
                    <?php foreach ($turmas as $turma): ?>
                        <option value="<?php echo $turma['idturma']; ?>" 
                            <?php echo $turma['idturma'] == $alocacao['idturma'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($turma['nome_turma']); ?> - <?php echo htmlspecialchars($turma['nome_curso']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label for="idcomponente">Componente Curricular:</label>
                <select id="idcomponente" name="idcomponente" required>
                    <?php foreach ($componentes as $componente): ?>
                        <option value="<?php echo $componente['idcomponente']; ?>" 
                            <?php echo $componente['idcomponente'] == $alocacao['idcomponente'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($componente['nome_componente']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label for="idstatus_alocacao">Status:</label>
                <select id="idstatus_alocacao" name="idstatus_alocacao" required>
                    <?php foreach ($status_alocacoes as $status): ?>
                        <option value="<?php echo $status['idstatus_alocacao']; ?>" 
                            <?php echo $status['nome_stalocacao'] == $alocacao['nome_stalocacao'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($status['nome_stalocacao']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label for="periodo_inicio">Período de Início:</label>
                <input type="date" id="periodo_inicio" name="periodo_inicio" 
                    value="<?php echo $alocacao['periodo_inicio']; ?>" required>
            </div>

            <div>
                <label for="periodo_fim">Período de Término:</label>
                <input type="date" id="periodo_fim" name="periodo_fim" 
                    value="<?php echo $alocacao['periodo_fim']; ?>" required>
            </div>

            <input type="submit" value="Atualizar Alocação">
        </form>
    <?php endif; ?>
</body>
</html>