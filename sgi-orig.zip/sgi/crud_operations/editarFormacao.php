<?php
session_start();
if (!isset($_SESSION['usuario']) || ($_SESSION['perfil'] !== 'Coordenacao' && $_SESSION['perfil'] !== 'Professores')) {
    header("Location: /sgi/index.php");
    exit;
}

$host = "localhost";
$dbname = "sgi";
$username = "root";
$password = "";

$erro = '';
$sucesso = '';

if (!isset($_GET['id'])) {
    header("Location: ../listarDocentes.php");
    exit;
}

$idFormacao = $_GET['id'];

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Buscar dados da formação
    $stmtFormacao = $pdo->prepare("
        SELECT f.*, p.nome_prof, p.idprofessor 
        FROM formacao_professor f
        JOIN professor p ON f.idprofessor = p.idprofessor
        WHERE f.idformacao = ?
    ");
    $stmtFormacao->execute([$idFormacao]);
    $formacao = $stmtFormacao->fetch(PDO::FETCH_ASSOC);

    if (!$formacao) {
        header("Location: ../listarDocentes.php");
        exit;
    }

    // Verificar permissões: coordenadores podem editar qualquer formação, 
    // professores só podem editar suas próprias formações
    if ($_SESSION['perfil'] === 'Professores' && $_SESSION['id_perfil'] != $formacao['idprofessor']) {
        header("Location: ../perfilDocente.php?id=" . $_SESSION['id_perfil']);
        exit;
    }

    // Processar o formulário
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $nome_formacao = $_POST["nome_formacao"];
        $tipo_formacao = $_POST["tipo_formacao"];
        $instituicao = $_POST["instituicao"];
        $ano_conclusao = $_POST["ano_conclusao"];
        $cargahr_formacao = $_POST["cargahr_formacao"];

        // Validar dados
        if (empty($nome_formacao) || empty($tipo_formacao) || empty($instituicao) || empty($ano_conclusao) || empty($cargahr_formacao)) {
            $erro = "Todos os campos são obrigatórios.";
        } elseif ($ano_conclusao > date('Y') + 5) {
            $erro = "Ano de conclusão inválido.";
        } elseif ($cargahr_formacao <= 0) {
            $erro = "Carga horária deve ser maior que zero.";
        } else {
            // Atualizar a formação
            $stmt = $pdo->prepare("
                UPDATE formacao_professor 
                SET nome_formacao = ?, tipo_formacao = ?, instituicao = ?, 
                    ano_conclusao = ?, cargahr_formacao = ?
                WHERE idformacao = ?
            ");
            $stmt->execute([$nome_formacao, $tipo_formacao, $instituicao, $ano_conclusao, $cargahr_formacao, $idFormacao]);

            $sucesso = "Formação atualizada com sucesso!";
            header("Refresh: 2; URL=../perfilDocente.php?id=" . $formacao['idprofessor']);
        }
    }

} catch (PDOException $e) {
    $erro = "Erro de conexão: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Formação</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .erro {
            color: #e74c3c;
            background-color: #fadbd8;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
        }
        .sucesso {
            color: #27ae60;
            background-color: #d5f4e6;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
        }
        form div {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input, select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            background-color: #3498db;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        input[type="submit"]:hover {
            background-color: #2980b9;
        }
        .voltar-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #3498db;
            text-decoration: none;
        }
        .voltar-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <a href="/sgi/views/perfilDocente.php?id=<?php echo $formacao['idprofessor']; ?>" class="voltar-link">← Voltar para Perfil</a>
    
    <h1>Editar Formação</h1>
    
    <h2>Docente: <?php echo htmlspecialchars($formacao['nome_prof']); ?></h2>

    <?php if (!empty($erro)): ?>
        <div class="erro"><?php echo $erro; ?></div>
    <?php endif; ?>

    <?php if (!empty($sucesso)): ?>
        <div class="sucesso"><?php echo $sucesso; ?></div>
        <p>Redirecionando para o perfil...</p>
    <?php else: ?>
        <form method="post">
            <div>
                <label for="nome_formacao">Título do Curso:</label>
                <input type="text" id="nome_formacao" name="nome_formacao" 
                    value="<?php echo htmlspecialchars($formacao['nome_formacao']); ?>" required>
            </div>

            <div>
                <label for="tipo_formacao">Tipo de Formação:</label>
                <select id="tipo_formacao" name="tipo_formacao" required>
                    <option value="">Selecione o tipo</option>
                    <option value="Graduação" <?php echo $formacao['tipo_formacao'] === 'Graduação' ? 'selected' : ''; ?>>Graduação</option>
                    <option value="Especialização" <?php echo $formacao['tipo_formacao'] === 'Especialização' ? 'selected' : ''; ?>>Especialização</option>
                    <option value="Mestrado" <?php echo $formacao['tipo_formacao'] === 'Mestrado' ? 'selected' : ''; ?>>Mestrado</option>
                    <option value="Doutorado" <?php echo $formacao['tipo_formacao'] === 'Doutorado' ? 'selected' : ''; ?>>Doutorado</option>
                </select>
            </div>

            <div>
                <label for="instituicao">Instituição:</label>
                <input type="text" id="instituicao" name="instituicao" 
                    value="<?php echo htmlspecialchars($formacao['instituicao']); ?>" required>
            </div>

            <div>
                <label for="ano_conclusao">Ano de Conclusão:</label>
                <input type="number" id="ano_conclusao" name="ano_conclusao" 
                    value="<?php echo htmlspecialchars($formacao['ano_conclusao']); ?>" 
                    min="1950" max="<?php echo date('Y') + 5; ?>" required>
            </div>

            <div>
                <label for="cargahr_formacao">Carga Horária:</label>
                <input type="number" id="cargahr_formacao" name="cargahr_formacao" 
                    value="<?php echo htmlspecialchars($formacao['cargahr_formacao']); ?>" 
                    min="1" required> horas
            </div>

            <input type="submit" value="Atualizar Formação">
        </form>
    <?php endif; ?>
</body>
</html>