<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['perfil'] !== 'Coordenacao') {
    header("Location: /sgi/index.php");
    exit;
}

$host = "localhost";
$dbname = "sgi";
$username = "root";
$password = "";

if (!isset($_GET['id'])) {
    header("Location: /sgi/views/listarDocentes.php");
    exit;
}

$idProfessor = $_GET['id'];

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Verificar se o professor existe
    $stmtProfessor = $pdo->prepare("SELECT idusuario FROM professor WHERE idprofessor = ?");
    $stmtProfessor->execute([$idProfessor]);
    $professor = $stmtProfessor->fetch(PDO::FETCH_ASSOC);

    if (!$professor) {
        header("Location: /sgi/views/listarDocentes.php?erro=Professor não encontrado");
        exit;
    }

    $idUsuario = $professor['idusuario'];

    // Iniciar transação
    $pdo->beginTransaction();

    // 1. Primeiro verificar e lidar com alocações do professor
    $stmtVerificaAlocacoes = $pdo->prepare("SELECT COUNT(*) as total FROM alocacao WHERE idprofessor = ?");
    $stmtVerificaAlocacoes->execute([$idProfessor]);
    $alocacoes = $stmtVerificaAlocacoes->fetch(PDO::FETCH_ASSOC);

    if ($alocacoes['total'] > 0) {
        // Opção 1: Cancelar as alocações em vez de excluir
        $stmtCancelarAlocacoes = $pdo->prepare("
            UPDATE alocacao 
            SET idstatus_alocacao = (SELECT idstatus_alocacao FROM status_alocacao WHERE nome_stalocacao = 'Cancelada') 
            WHERE idprofessor = ?
        ");
        $stmtCancelarAlocacoes->execute([$idProfessor]);
        
        // Ou Opção 2: Excluir as alocações (mais radical)
        // $stmtExcluirAlocacoes = $pdo->prepare("DELETE FROM alocacao WHERE idprofessor = ?");
        // $stmtExcluirAlocacoes->execute([$idProfessor]);
    }

    // 2. Excluir formações do professor
    $stmtFormacoes = $pdo->prepare("DELETE FROM formacao_professor WHERE idprofessor = ?");
    $stmtFormacoes->execute([$idProfessor]);

    // 3. Verificar e lidar com candidaturas do professor (se a tabela existir)
    try {
        $stmtVerificaCandidaturas = $pdo->prepare("SELECT COUNT(*) as total FROM candidatura WHERE idprofessor = ?");
        $stmtVerificaCandidaturas->execute([$idProfessor]);
        $candidaturas = $stmtVerificaCandidaturas->fetch(PDO::FETCH_ASSOC);
        
        if ($candidaturas['total'] > 0) {
            $stmtExcluirCandidaturas = $pdo->prepare("DELETE FROM candidatura WHERE idprofessor = ?");
            $stmtExcluirCandidaturas->execute([$idProfessor]);
        }
    } catch (PDOException $e) {
        // Tabela candidatura pode não existir, ignorar erro
    }

    // 4. Excluir o professor
    $stmtExcluirProfessor = $pdo->prepare("DELETE FROM professor WHERE idprofessor = ?");
    $stmtExcluirProfessor->execute([$idProfessor]);

    // 5. Excluir o usuário
    $stmtExcluirUsuario = $pdo->prepare("DELETE FROM usuario WHERE idusuarior = ?");
    $stmtExcluirUsuario->execute([$idUsuario]);

    // Confirmar transação
    $pdo->commit();

    header("Location: /sgi/views/listarDocentes.php?sucesso=Professor excluído com sucesso");
    exit;

} catch (PDOException $e) {
    // Reverter transação em caso de erro
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    // Verificar se é erro de constraint foreign key
    if (strpos($e->getMessage(), 'foreign key constraint') !== false) {
        header("Location: /sgi/views/listarDocentes.php?erro=Não é possível excluir o professor pois existem alocações ou outras dependências associadas. Use a opção de cancelar alocações primeiro.");
    } else {
        header("Location: /sgi/views/listarDocentes.php?erro=Erro ao excluir professor: " . urlencode($e->getMessage()));
    }
    exit;
}
?>