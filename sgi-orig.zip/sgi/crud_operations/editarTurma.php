<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['perfil'] !== 'Coordenacao') {
    header("Location: /sgi/index.php");
    exit;
}

$host = "localhost";
$dbname = "sgi";
$username = "root";
$password = "";

$erro = '';
$sucesso = '';

if (!isset($_GET['id'])) {
    header("Location: ../listarTurmas.php");
    exit;
}

$idTurma = $_GET['id'];

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Buscar dados da turma
    $stmtTurma = $pdo->prepare("
        SELECT t.*, c.nome_curso, tu.nome_turno, st.nome_stturma, g.dt_vigencia
        FROM turma t
        JOIN curso c ON t.idcurso = c.idcurso
        JOIN turno tu ON t.idturno = tu.idturno
        JOIN status_turma st ON t.idstatus_turma = st.idstatus_turma
        JOIN grade_curricular g ON t.idgrade_curricular = g.idgrade_curricular
        WHERE t.idturma = ?
    ");
    $stmtTurma->execute([$idTurma]);
    $turma = $stmtTurma->fetch(PDO::FETCH_ASSOC);

    if (!$turma) {
        header("Location: ../listarTurmas.php");
        exit;
    }

    // Buscar dados para os selects - CORREÇÃO: Remover subconsultas problemáticas
    $stmtCursos = $pdo->prepare("
        SELECT c.idcurso, c.nome_curso 
        FROM curso c 
        JOIN status_curso sc ON c.idstatus_curso = sc.idstatus_curso 
        WHERE sc.nome_stcurso = 'Ativo'
    ");
    $stmtCursos->execute();
    $cursos = $stmtCursos->fetchAll(PDO::FETCH_ASSOC);

    $stmtTurnos = $pdo->prepare("SELECT idturno, nome_turno FROM turno");
    $stmtTurnos->execute();
    $turnos = $stmtTurnos->fetchAll(PDO::FETCH_ASSOC);

    $stmtStatus = $pdo->prepare("SELECT idstatus_turma, nome_stturma FROM status_turma");
    $stmtStatus->execute();
    $status_turmas = $stmtStatus->fetchAll(PDO::FETCH_ASSOC);

    $stmtGrades = $pdo->prepare("
        SELECT idgrade_curricular, status_grade, dt_vigencia 
        FROM grade_curricular 
        WHERE status_grade = 'Ativo'
    ");
    $stmtGrades->execute();
    $grades = $stmtGrades->fetchAll(PDO::FETCH_ASSOC);

    // Processar o formulário
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $nome_turma = $_POST["nome_turma"];
        $dt_inicio = $_POST["dt_inicio"];
        $dt_fim = $_POST["dt_fim"];
        $idstatus_turma = $_POST["idstatus_turma"];
        $idturno = $_POST["idturno"];
        $idgrade_curricular = $_POST["idgrade_curricular"];
        $idcurso = $_POST["idcurso"];

        // Validar datas
        if ($dt_inicio >= $dt_fim) {
            $erro = "A data de início deve ser anterior à data de fim.";
        } else {
            // Atualizar a turma
            $stmt = $pdo->prepare("
                UPDATE turma 
                SET nome_turma = ?, dt_inicio = ?, dt_fim = ?, 
                    idstatus_turma = ?, idturno = ?, idgrade_curricular = ?, idcurso = ?
                WHERE idturma = ?
            ");
            $stmt->execute([$nome_turma, $dt_inicio, $dt_fim, $idstatus_turma, $idturno, $idgrade_curricular, $idcurso, $idTurma]);

            $sucesso = "Turma atualizada com sucesso!";
            header("Refresh: 2; URL=../listarTurmas.php");
        }
    }

} catch (PDOException $e) {
    $erro = "Erro de conexão: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Turma</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; }
        .erro { color: red; background-color: #fadbd8; padding: 10px; border-radius: 4px; }
        .sucesso { color: green; background-color: #d5f4e6; padding: 10px; border-radius: 4px; }
        form div { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        select, input { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; }
        input[type="submit"] { background-color: #3498db; color: white; padding: 10px 15px; border: none; border-radius: 4px; cursor: pointer; }
    </style>
</head>
<body>
    <h1>Editar Turma</h1>
    <a href="/sgi/views/listarTurmas.php">Voltar para Lista</a>

    <?php if (!empty($erro)): ?>
        <div class="erro"><?php echo $erro; ?></div>
    <?php endif; ?>

    <?php if (!empty($sucesso)): ?>
        <div class="sucesso"><?php echo $sucesso; ?></div>
        <p>Redirecionando para a lista de turmas...</p>
    <?php else: ?>
        <form method="post">
            <div>
                <label for="nome_turma">Nome da Turma:</label>
                <input type="text" id="nome_turma" name="nome_turma" value="<?php echo htmlspecialchars($turma['nome_turma']); ?>" required>
            </div>

            <div>
                <label for="dt_inicio">Data de Início:</label>
                <input type="date" id="dt_inicio" name="dt_inicio" value="<?php echo $turma['dt_inicio']; ?>" required>
            </div>

            <div>
                <label for="dt_fim">Data de Término:</label>
                <input type="date" id="dt_fim" name="dt_fim" value="<?php echo $turma['dt_fim']; ?>" required>
            </div>

            <div>
                <label for="idstatus_turma">Status da Turma:</label>
                <select id="idstatus_turma" name="idstatus_turma" required>
                    <?php foreach ($status_turmas as $status): ?>
                        <option value="<?php echo $status['idstatus_turma']; ?>" 
                            <?php echo $status['idstatus_turma'] == $turma['idstatus_turma'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($status['nome_stturma']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label for="idturno">Turno:</label>
                <select id="idturno" name="idturno" required>
                    <?php foreach ($turnos as $turno): ?>
                        <option value="<?php echo $turno['idturno']; ?>" 
                            <?php echo $turno['idturno'] == $turma['idturno'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($turno['nome_turno']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label for="idgrade_curricular">Grade Curricular:</label>
                <select id="idgrade_curricular" name="idgrade_curricular" required>
                    <?php foreach ($grades as $grade): ?>
                        <option value="<?php echo $grade['idgrade_curricular']; ?>" 
                            <?php echo $grade['idgrade_curricular'] == $turma['idgrade_curricular'] ? 'selected' : ''; ?>>
                            Grade (Vigência: <?php echo date('d/m/Y', strtotime($grade['dt_vigencia'])); ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label for="idcurso">Curso:</label>
                <select id="idcurso" name="idcurso" required>
                    <?php foreach ($cursos as $curso): ?>
                        <option value="<?php echo $curso['idcurso']; ?>" 
                            <?php echo $curso['idcurso'] == $turma['idcurso'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($curso['nome_curso']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <input type="submit" value="Atualizar Turma">
        </form>
    <?php endif; ?>
</body>
</html>