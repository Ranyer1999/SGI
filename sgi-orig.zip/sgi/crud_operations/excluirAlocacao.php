<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['perfil'] !== 'Coordenacao') {
    header("Location: /sgi/index.php");
    exit;
}

$host = "localhost";
$dbname = "sgi";
$username = "root";
$password = "";

if (!isset($_GET['id'])) {
    header("Location: /sgi/views/listarAlocacoes.php");
    exit;
}

$idAlocacao = $_GET['id'];

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Verificar se a alocação existe
    $stmtVerifica = $pdo->prepare("SELECT idalocacao FROM alocacao WHERE idalocacao = ?");
    $stmtVerifica->execute([$idAlocacao]);
    
    if (!$stmtVerifica->fetch()) {
        header("Location: /sgi/views/listarAlocacoes.php?erro=Alocação não encontrada");
        exit;
    }

    // Excluir a alocação
    $stmtExcluir = $pdo->prepare("DELETE FROM alocacao WHERE idalocacao = ?");
    $stmtExcluir->execute([$idAlocacao]);

    header("Location: /sgi/views/listarAlocacoes.php?sucesso=Alocação excluída com sucesso");
    exit;

} catch (PDOException $e) {
    header("Location: /sgi/views/listarAlocacoes.php?erro=Erro ao excluir alocação: " . urlencode($e->getMessage()));
    exit;
}
?>