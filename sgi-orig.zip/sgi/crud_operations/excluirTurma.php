<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['perfil'] !== 'Coordenacao') {
    header("Location: /sgi/index.php");
    exit;
}

$host = "localhost";
$dbname = "sgi";
$username = "root";
$password = "";

if (!isset($_GET['id'])) {
    header("Location: /sgi/views/listarTurmas.php");
    exit;
}

$idTurma = $_GET['id'];

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Verificar se a turma existe
    $stmtVerifica = $pdo->prepare("SELECT idturma FROM turma WHERE idturma = ?");
    $stmtVerifica->execute([$idTurma]);
    
    if (!$stmtVerifica->fetch()) {
        header("Location: /sgi/views/listarTurmas.php?erro=Turma não encontrada");
        exit;
    }

    // Verificar se há alocações associadas à turma
    $stmtAlocacoes = $pdo->prepare("SELECT COUNT(*) as total FROM alocacao WHERE idturma = ?");
    $stmtAlocacoes->execute([$idTurma]);
    $alocacoes = $stmtAlocacoes->fetch(PDO::FETCH_ASSOC);

    if ($alocacoes['total'] > 0) {
        header("Location: /sgi/views/listarTurmas.php?erro=Não é possível excluir a turma pois existem alocações associadas a ela");
        exit;
    }

    // Excluir a turma
    $stmtExcluir = $pdo->prepare("DELETE FROM turma WHERE idturma = ?");
    $stmtExcluir->execute([$idTurma]);

    header("Location: /sgi/views/listarTurmas.php?sucesso=Turma excluída com sucesso");
    exit;

} catch (PDOException $e) {
    header("Location: /sgi/views/listarTurmas.php?erro=Erro ao excluir turma: " . urlencode($e->getMessage()));
    exit;
}
?>