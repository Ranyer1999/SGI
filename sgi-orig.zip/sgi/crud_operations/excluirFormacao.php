<?php
session_start();
if (!isset($_SESSION['usuario']) || ($_SESSION['perfil'] !== 'Coordenacao' && $_SESSION['perfil'] !== 'Professores')) {
    header("Location: /sgi/index.php");
    exit;
}

$host = "localhost";
$dbname = "sgi";
$username = "root";
$password = "";

if (!isset($_GET['id'])) {
    header("Location: sgi/views/listarDocentes.php");
    exit;
}

$idFormacao = $_GET['id'];

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Buscar dados da formação para verificar permissões
    $stmtFormacao = $pdo->prepare("
        SELECT f.*, p.idprofessor 
        FROM formacao_professor f
        JOIN professor p ON f.idprofessor = p.idprofessor
        WHERE f.idformacao = ?
    ");
    $stmtFormacao->execute([$idFormacao]);
    $formacao = $stmtFormacao->fetch(PDO::FETCH_ASSOC);

    if (!$formacao) {
        header("Location: /sgi/views/listarDocentes.php");
        exit;
    }

    // Verificar permissões: coordenadores podem excluir qualquer formação, 
    // professores só podem excluir suas próprias formações
    if ($_SESSION['perfil'] === 'Professores' && $_SESSION['id_perfil'] != $formacao['idprofessor']) {
        header("Location: /sgi/views/perfilDocente.php?id=" . $_SESSION['id_perfil']);
        exit;
    }

    // Excluir a formação
    $stmtExcluir = $pdo->prepare("DELETE FROM formacao_professor WHERE idformacao = ?");
    $stmtExcluir->execute([$idFormacao]);

    header("Location: /sgi/views/perfilDocente.php?id=" . $formacao['idprofessor'] . "&sucesso=Formação excluída com sucesso");
    exit;

} catch (PDOException $e) {
    header("Location: /sgi/views/perfilDocente.php?id=" . $formacao['idprofessor'] . "&erro=Erro ao excluir formação: " . urlencode($e->getMessage()));
    exit;
}
?>