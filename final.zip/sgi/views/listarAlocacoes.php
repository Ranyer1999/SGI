<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['perfil'] !== 'Coordenacao') {
    header("Location: /sgi/index.php");
    exit;
}

$host = "localhost";
$dbname = "sgi";
$username = "root";
$password = "";

$filtro_status = $_GET['status'] ?? '';
$filtro_professor = $_GET['professor'] ?? '';
$filtro_turma = $_GET['turma'] ?? '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Construir a query base com filtros
    $sql = "
        SELECT 
            a.idalocacao,
            a.dt_alocacao,
            a.periodo_inicio,
            a.periodo_fim,
            p.idprofessor,
            p.nome_prof,
            t.idturma,
            t.nome_turma,
            c.nome_curso,
            s.nome_stalocacao as status_alocacao
        FROM alocacao a
        JOIN professor p ON a.idprofessor = p.idprofessor
        JOIN turma t ON a.idturma = t.idturma
        JOIN curso c ON t.idcurso = c.idcurso
        JOIN status_alocacao s ON a.idstatus_alocacao = s.idstatus_alocacao
        WHERE 1=1
    ";
    
    $params = [];
    
    if (!empty($filtro_status)) {
        $sql .= " AND s.nome_stalocacao = ?";
        $params[] = $filtro_status;
    }
    
    if (!empty($filtro_professor)) {
        $sql .= " AND p.nome_prof LIKE ?";
        $params[] = "%$filtro_professor%";
    }
    
    if (!empty($filtro_turma)) {
        $sql .= " AND t.nome_turma LIKE ?";
        $params[] = "%$filtro_turma%";
    }
    
    $sql .= " ORDER BY a.dt_alocacao DESC, p.nome_prof";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $alocacoes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Buscar status para o filtro
    $stmtStatus = $pdo->prepare("SELECT DISTINCT nome_stalocacao FROM status_alocacao ORDER BY nome_stalocacao");
    $stmtStatus->execute();
    $status_lista = $stmtStatus->fetchAll(PDO::FETCH_COLUMN);
    
} catch (PDOException $e) {
    $erro = "Erro ao carregar alocações: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Lista de Alocações</title>

</head>
<body>
    <h1>Alocações de Professores</h1>
    
    <a href="homeCoordenacao.php" class="btn-voltar">Voltar para Home</a>
    <a href="cadastrarAlocacoes.php" class="btn-novo">Nova Alocação</a>
    
    <?php if (isset($erro)): ?>
        <div style="color: red; background-color: #fadbd8; padding: 10px; border-radius: 4px; margin-bottom: 15px;">
            <?php echo $erro; ?>
        </div>
    <?php endif; ?>
    
    <div class="filtros">
        <h3>Filtrar Alocações</h3>
        <form method="get">
            <div>
                <label for="status">Status:</label>
                <select id="status" name="status">
                    <option value="">Todos os status</option>
                    <?php foreach ($status_lista as $status): ?>
                        <option value="<?php echo $status; ?>" <?php echo $filtro_status === $status ? 'selected' : ''; ?>>
                            <?php echo $status; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div>
                <label for="professor">Professor:</label>
                <input type="text" id="professor" name="professor" value="<?php echo htmlspecialchars($filtro_professor); ?>" placeholder="Nome do professor">
            </div>
            
            <div>
                <label for="turma">Turma:</label>
                <input type="text" id="turma" name="turma" value="<?php echo htmlspecialchars($filtro_turma); ?>" placeholder="Nome da turma">
            </div>
            
            <div>
                <input type="submit" value="Filtrar" class="btn-filtrar">
            </div>
        </form>
        
        <?php if ($filtro_status || $filtro_professor || $filtro_turma): ?>
            <a href="listarAlocacoes.php" class="btn-limpar">Limpar Filtros</a>
        <?php endif; ?>
    </div>
    
    <?php if (count($alocacoes) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Professor</th>
                    <th>Turma</th>
                    <th>Curso</th>
                    <th>Data Alocação</th>
                    <th>Período</th>
                    <th>Status</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($alocacoes as $alocacao): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($alocacao['nome_prof']); ?></td>
                        <td><?php echo htmlspecialchars($alocacao['nome_turma']); ?></td>
                        <td><?php echo htmlspecialchars($alocacao['nome_curso']); ?></td>
                        <td><?php echo date('d/m/Y', strtotime($alocacao['dt_alocacao'])); ?></td>
                        <td>
                            <?php echo date('d/m/Y', strtotime($alocacao['periodo_inicio'])); ?> 
                            a 
                            <?php echo date('d/m/Y', strtotime($alocacao['periodo_fim'])); ?>
                        </td>
                        <td>
                            <?php 
                            $classe_status = '';
                            if ($alocacao['status_alocacao'] === 'Ativa') {
                                $classe_status = 'status-ativa';
                            } elseif ($alocacao['status_alocacao'] === 'Encerrada') {
                                $classe_status = 'status-encerrada';
                            } elseif ($alocacao['status_alocacao'] === 'Cancelada') {
                                $classe_status = 'status-cancelada';
                            }
                            ?>
                            <span class="<?php echo $classe_status; ?>">
                                <?php echo htmlspecialchars($alocacao['status_alocacao']); ?>
                            </span>
                        </td>
                        <td class="acoes">
                            <a href="visualizarAlocacao.php?id=<?php echo $alocacao['idalocacao']; ?>" class="visualizar">Visualizar</a>
                            <a href="editarAlocacao.php?id=<?php echo $alocacao['idalocacao']; ?>" class="editar">Editar</a>
                            <a href="excluirAlocacao.php?id=<?php echo $alocacao['idalocacao']; ?>" class="excluir" onclick="return confirm('Tem certeza que deseja excluir esta alocação?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <div class="sem-registros">
            <h3>Nenhuma alocação encontrada</h3>
            <p><?php echo ($filtro_status || $filtro_professor || $filtro_turma) ? 'Tente ajustar os filtros.' : 'Cadastre a primeira alocação.'; ?></p>
        </div>
    <?php endif; ?>
    <a href="cadastrarAlocacoes.php">Cadastar nova Alocação</a>
</body>
</html>