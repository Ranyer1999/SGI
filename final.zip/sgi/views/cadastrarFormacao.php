<?php
session_start();
if (!isset($_SESSION['usuario']) || ($_SESSION['perfil'] !== 'Coordenacao' && $_SESSION['perfil'] !== 'Professores')) {
    header("Location: /sgi/index.php");
    exit;
}

    $host = "localhost";
    $dbname = "sgi";
    $username = "root";
    $password = "";

$erro = '';
$sucesso = '';

// Obter ID do professor
$idProfessor = $_GET['id'] ?? ($_SESSION['perfil'] === 'Professores' ? $_SESSION['id_perfil'] : 0);

if (!$idProfessor) {
    header("Location: listarDocentes.php");
    exit;
}

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Buscar dados do professor
    $stmtProfessor = $pdo->prepare("SELECT * FROM professor WHERE idprofessor = ?");
    $stmtProfessor->execute([$idProfessor]);
    $professor = $stmtProfessor->fetch(PDO::FETCH_ASSOC);

    if (!$professor) {
        header("Location: listarDocentes.php");
        exit;
    }

    // Processar formulário
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $nome_formacao = $_POST["nome_formacao"];
        $tipo_formacao = $_POST["tipo_formacao"];
        $instituicao = $_POST["instituicao"];
        $ano_conclusao = $_POST["ano_conclusao"];
        $cargahr_formacao = $_POST["cargahr_formacao"];

        // Validar dados
        if (empty($nome_formacao) || empty($tipo_formacao) || empty($instituicao) || empty($ano_conclusao) || empty($cargahr_formacao)) {
            $erro = "Todos os campos são obrigatórios.";
        } elseif ($ano_conclusao > date('Y') + 5) {
            $erro = "Ano de conclusão inválido.";
        } elseif ($cargahr_formacao <= 0) {
            $erro = "Carga horária deve ser maior que zero.";
        } else {
            // Inserir formação
            $stmt = $pdo->prepare("
                INSERT INTO formacao_professor (nome_formacao, tipo_formacao, instituicao, ano_conclusao, cargahr_formacao, idprofessor) 
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([$nome_formacao, $tipo_formacao, $instituicao, $ano_conclusao, $cargahr_formacao, $idProfessor]);

            $sucesso = "Formação cadastrada com sucesso!";

            // Redirecionar após cadastro bem-sucedido
            if ($_SESSION['perfil'] === 'Coordenacao') {
                header("Refresh: 2; URL=perfilDocente.php?id=" . $idProfessor);
            } else {
                header("Refresh: 2; URL=perfilDocente.php?id=" . $idProfessor);
            }
        }
    }
} catch (PDOException $e) {
    $erro = "Erro de conexão: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Cadastrar Formação</title>
</head>

<body>
    <h1>Cadastrar Formação</h1>

    <?php if ($_SESSION['perfil'] === 'Coordenacao'): ?>
    <a href="perfilDocente.php?id=<?php echo $idProfessor; ?>">Voltar para Perfil</a> |
    <a href="listarDocentes.php">Voltar para Lista de Docentes</a>
    <?php else: ?>
    <a href="perfilDocente.php?id=<?php echo $idProfessor; ?>">Voltar para Meu Perfil</a>
    <?php endif; ?>

    <h2>Docente: <?php echo $professor['nome_prof']; ?></h2>

    <?php if (!empty($erro)): ?>
    <div style="color: red; border: 1px solid red; padding: 10px; margin: 10px 0;"><?php echo $erro; ?></div>
    <?php endif; ?>

    <?php if (!empty($sucesso)): ?>
    <div style="color: green; border: 1px solid green; padding: 10px; margin: 10px 0;"><?php echo $sucesso; ?></div>
    <p>Redirecionando para o perfil...</p>
    <?php else: ?>
    <form method="post">
        <table>
            <tr>
                <td><label for="nome_formacao">Título do Curso:</label></td>
                <td><input type="text" id="nome_formacao" name="nome_formacao" required></td>
            </tr>
            <tr>
                <td><label for="tipo_formacao">Tipo de Formação:</label></td>
                <td>
                    <select id="tipo_formacao" name="tipo_formacao" required>
                        <option value="">Selecione o tipo</option>
                        <option value="Graduação">Graduação</option>
                        <option value="Especialização">Especialização</option>
                        <option value="Mestrado">Mestrado</option>
                        <option value="Doutorado">Doutorado</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td><label for="instituicao">Instituição:</label></td>
                <td><input type="text" id="instituicao" name="instituicao" required></td>
            </tr>
            <tr>
                <td><label for="ano_conclusao">Ano de Conclusão:</label></td>
                <td><input type="number" id="ano_conclusao" name="ano_conclusao" min="1950"
                        max="<?php echo date('Y') + 5; ?>" required></td>
            </tr>
            <tr>
                <td><label for="cargahr_formacao">Carga Horária:</label></td>
                <td><input type="number" id="cargahr_formacao" name="cargahr_formacao" min="1" required> horas</td>
            </tr>
            <tr>
                <td colspan="2" style="text-align: center;">
                    <input type="submit" value="Cadastrar Formação">
                </td>
            </tr>
        </table>
    </form>
    <?php endif; ?>
</body>

</html>