<?php
class CadastrarController extends Controller
{
    public $dados;

    public function __construct()
    {
        $this->dados = array();
    }

    public function index()
    {
        // Se quiser mandar dados para a view cadastrar, crie um array
        $dadosModel = array(
            'titulo' => 'Cadastro de Usuário',
            'mensagem' => 'Preencha seus dados'
        );
        $this->carregarTemplate('cadastrar', $dadosModel);
    }

    public function carregarTemplate($nomeView, $dadosModel = array())
    {
        $this->dados = $dadosModel;
        // Passando o nome da view para o template saber qual incluir
        $nomeDaView = $nomeView;
        require 'views/template.php';
    }

    public function carregarViewNoTemplate($nomeView, $dadosModel = array())
    {
        extract($dadosModel, EXTR_SKIP);
        require 'views/' . $nomeView . '.php';
    }
}
