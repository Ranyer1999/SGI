<?php
echo 'Seja bem vindo Ranyer!';
