<h2><?php echo isset($titulo) ? htmlspecialchars($titulo) : "Cadastrar"; ?></h2>
<p><?php echo isset($mensagem) ? htmlspecialchars($mensagem) : ""; ?></p>

<form action="?controller=cadastrar&action=salvar" method="post">
    <label for="nome">Nome:</label>
    <input type="text" name="nome" id="nome">
    <br>
    <label for="email">Email:</label>
    <input type="email" name="email" id="email">
    <br>
    <button type="submit">Cadastrar</button>
</form>