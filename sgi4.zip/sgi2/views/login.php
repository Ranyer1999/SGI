<link rel="stylesheet" href="public/css/style.css">
<form method="post" class="login-form">

    <h2>Login</h2>

    <?php if (!empty($erro)): ?>
    <div class="error"><?= htmlspecialchars($erro) ?></div>
    <?php endif; ?>

    Email:<br><input type="email" name="email" required><br>
    Senha:<br><input type="password" name="senha" required><br>
    <input type="submit" value="Acessar">
    <a href="link.php">Recuperar Senha</a>
</form>