<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['perfil'] !== 'Coordenacao') {
    header("Location: /sgi/index.php");
    exit;
}

$host = "localhost";
$dbname = "sgi";
$username = "root";
$password = "";

$erro = '';
$sucesso = '';

if (!isset($_GET['id'])) {
    header("Location: /sgi/views/listarDocentes.php");
    exit;
}

$idProfessor = $_GET['id'];

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Buscar dados do professor
    $stmt = $pdo->prepare("SELECT * FROM professor WHERE idprofessor = ?");
    $stmt->execute([$idProfessor]);
    $professor = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$professor) {
        header("Location: /sgi/views/listarDocentes.php");
        exit;
    }

    // Processar o formulário
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $nome_prof = $_POST["nome_prof"];
        $cpf = $_POST["cpf"];
        $telefone = $_POST["telefone"];
        $dt_nascimento = $_POST["dt_nascimento"];
        $email_prof = $_POST["email_prof"];

        // Validar CPF
        if (!validarCPF($cpf)) {
            $erro = "CPF inválido.";
        }
        // Validar telefone
        else if (!validarTelefone($telefone)) {
            $erro = "Telefone inválido.";
        } else {
            // Verificar se o email já existe em outro professor
            $stmtVerificaEmail = $pdo->prepare("SELECT idprofessor FROM professor WHERE email_prof = ? AND idprofessor != ?");
            $stmtVerificaEmail->execute([$email_prof, $idProfessor]);

            if ($stmtVerificaEmail->fetch()) {
                $erro = "Este email já está cadastrado para outro professor.";
            } else {
                // Verificar se o CPF já existe em outro professor
                $stmtVerificaCPF = $pdo->prepare("SELECT idprofessor FROM professor WHERE cpf = ? AND idprofessor != ?");
                $stmtVerificaCPF->execute([preg_replace('/[^0-9]/', '', $cpf), $idProfessor]);

                if ($stmtVerificaCPF->fetch()) {
                    $erro = "Este CPF já está cadastrado para outro professor.";
                } else {
                    // Atualizar o professor
                    $stmtUpdate = $pdo->prepare("
                        UPDATE professor 
                        SET nome_prof = ?, cpf = ?, telefone = ?, dt_nascimento = ?, email_prof = ?
                        WHERE idprofessor = ?
                    ");
                    $stmtUpdate->execute([
                        $nome_prof,
                        preg_replace('/[^0-9]/', '', $cpf),
                        preg_replace('/[^0-9]/', '', $telefone),
                        $dt_nascimento,
                        $email_prof,
                        $idProfessor
                    ]);

                    // Atualizar também o login do usuário se o email foi alterado
                    if ($email_prof != $professor['email_prof']) {
                        $stmtUpdateUsuario = $pdo->prepare("
                            UPDATE usuario SET user_login = ? WHERE idusuario = ?
                        ");
                        $stmtUpdateUsuario->execute([$email_prof, $professor['idusuario']]);
                    }

                    $sucesso = "Professor atualizado com sucesso!";
                    header("Refresh: 2; URL=/sgi/views/listarDocentes.php");
                }
            }
        }
    }

} catch (PDOException $e) {
    $erro = "Erro de conexão: " . $e->getMessage();
}

// Funções de validação (reutilizadas do cadastrarDocentes.php)
function validarCPF($cpf) {
    $cpf = preg_replace('/[^0-9]/', '', $cpf);
    if (strlen($cpf) != 11) return false;
    if (preg_match('/(\d)\1{10}/', $cpf)) return false;
    for ($t = 9; $t < 11; $t++) {
        for ($d = 0, $c = 0; $c < $t; $c++) {
            $d += $cpf[$c] * (($t + 1) - $c);
        }
        $d = ((10 * $d) % 11) % 10;
        if ($cpf[$c] != $d) return false;
    }
    return true;
}

function validarTelefone($telefone) {
    $telefone = preg_replace('/[^0-9]/', '', $telefone);
    return strlen($telefone) >= 10 && strlen($telefone) <= 11;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Docente</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
        .erro { color: #e74c3c; background-color: #fadbd8; padding: 10px; border-radius: 4px; margin-bottom: 15px; }
        .sucesso { color: #27ae60; background-color: #d5f4e6; padding: 10px; border-radius: 4px; margin-bottom: 15px; }
        form div { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }
        input[type="submit"] { background-color: #3498db; color: white; padding: 10px 15px; border: none; border-radius: 4px; cursor: pointer; }
    </style>
</head>
<body>
    <h1>Editar Docente</h1>
    <a href="/sgi/views/listarDocentes.php">Voltar para Lista</a>

    <?php if (!empty($erro)): ?>
        <div class="erro"><?php echo $erro; ?></div>
    <?php endif; ?>

    <?php if (!empty($sucesso)): ?>
        <div class="sucesso"><?php echo $sucesso; ?></div>
        <p>Redirecionando para a lista de docentes...</p>
    <?php else: ?>
        <form method="post" id="formEditar">
            <div>
                <label for="nome_prof">Nome Completo:</label>
                <input type="text" id="nome_prof" name="nome_prof" value="<?php echo htmlspecialchars($professor['nome_prof']); ?>" required>
            </div>

            <div>
                <label for="cpf">CPF:</label>
                <input type="text" id="cpf" name="cpf" value="<?php echo htmlspecialchars($professor['cpf']); ?>" required>
            </div>

            <div>
                <label for="telefone">Telefone:</label>
                <input type="text" id="telefone" name="telefone" value="<?php echo htmlspecialchars($professor['telefone']); ?>" required>
            </div>

            <div>
                <label for="dt_nascimento">Data de Nascimento:</label>
                <input type="date" id="dt_nascimento" name="dt_nascimento" value="<?php echo $professor['dt_nascimento']; ?>" required>
            </div>

            <div>
                <label for="email_prof">Email:</label>
                <input type="email" id="email_prof" name="email_prof" value="<?php echo htmlspecialchars($professor['email_prof']); ?>" required>
            </div>

            <input type="submit" value="Atualizar Professor">
        </form>
    <?php endif; ?>
</body>
</html>