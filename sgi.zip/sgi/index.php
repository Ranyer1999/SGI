<!DOCTYPE html>
<html lang="pt-br">

<head>
    <link rel="shortcut icon" href="/sgi/public/img/icon.png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Gestão Institucional - Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="/sgi/public/css/style.css">
</head>

<body class="d-flex align-items-center min-vh-100 ">

    <?php
    session_start();
    $erro = "";

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $host = "localhost";
        $dbname = "sgi";
        $username = "root";
        $password = "";

        try {
            $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $email = $_POST["email"];
            $senha = $_POST["senha"];

            // Verificar se é um coordenador, professor ou administrador
            $stmt = $pdo->prepare("
            SELECT u.*, g.nome_grupo, 
                   CASE 
                     WHEN g.nome_grupo = 'Professores' THEN p.idprofessor
                     WHEN g.nome_grupo = 'Coordenacao' THEN c.idcoordenador
                     WHEN g.nome_grupo = 'Administradores' THEN a.idadmin
                   END as id_perfil
            FROM usuario u 
            JOIN grupo_acesso g ON u.idgrupo_acesso = g.idgrupo_acesso 
            LEFT JOIN professor p ON u.idusuario = p.idusuario AND g.nome_grupo = 'Professores'
            LEFT JOIN coordenador c ON u.idusuario = c.idusuario AND g.nome_grupo = 'Coordenacao'
            LEFT JOIN administrador a ON u.idusuario = a.idusuario AND g.nome_grupo = 'Administradores'
            WHERE u.user_login = ? AND u.senha = ? 
            AND (g.nome_grupo = 'Coordenacao' OR g.nome_grupo = 'Professores' OR g.nome_grupo = 'Administradores')
        ");
            $stmt->execute([$email, $senha]);
            $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($usuario) {
                $_SESSION["usuario"] = $usuario["user_login"];
                $_SESSION["perfil"] = $usuario["nome_grupo"];
                $_SESSION["id_usuario"] = $usuario["idusuario"];
                $_SESSION["id_perfil"] = $usuario["id_perfil"];

                // Redireciona conforme o perfil
                if ($usuario["nome_grupo"] === "Coordenacao") {
                    header("Location: views/homeCoordenacao.php");
                } else if ($usuario["nome_grupo"] === "Administradores") {
                    header("Location: homeAdmin.php");
                } else {
                    // Redireciona para o perfil do professor
                    header("Location:views/perfilDocente.php?id=" . $usuario["id_perfil"]);
                }
                exit;
            } else {
                $erro = "Email ou senha inválidos.";
            }
        } catch (PDOException $e) {
            $erro = "Erro de conexão: " . $e->getMessage();
        }
    }
    ?>

    <div class="container-fluid">
        <div class="row justify-content-center align-items-center min-vh-100">
            <div class="col-lg-10 col-xl-9">
                <div class="card shadow-lg login-container">
                    <div class="row g-0">
                        <!-- Painel de Boas-vindas -->
                        <div class="col-md-6 welcome-panel">
                            <div class="card-body d-flex flex-column h-100 p-5">
                                <div class="mb-auto">
                                    <img src="/sgi/public/img/sgi.png" alt="Logo SGI" class="logo-sgi img-fluid mb-0">
                                </div>
                                <div class="welcome-content">
                                    <h1 class="fw-bold mb-5">Bem-vindo ao SGI!</h1>
                                    <p class="slogan-text">Tecnologia a serviço da educação</p>
                                </div>
                            </div>
                        </div>

                        <!-- Painel de Login -->
                        <div class="col-md-6 login-panel bg-sucess">
                            <div class="card-body p-5 d-flex flex-column justify-content-center h-100">
                                <h3 class="text-center mb-4 fw-bold text-uppercase text-white">LOGIN</h3>

                                <?php if (!empty($erro)): ?>
                                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                        <?= htmlspecialchars($erro) ?>
                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                    </div>
                                <?php endif; ?>

                                <form method="post">
                                    <div class="mb-3">
                                        <label for="email" class="form-label fw-semibold text-white">EMAIL:</label>
                                        <div class="input-group">
                                            <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                            <input type="email" class="form-control" id="email" name="email" required>
                                        </div>
                                    </div>
                                    <div class="mb-4">
                                        <label for="senha" class="form-label fw-semibold text-white">SENHA:</label>
                                        <div class="input-group">
                                            <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                            <input type="password" class="form-control" id="senha" name="senha" required>
                                        </div>
                                    </div>
                                    <div class="d-grid mb-3">
                                        <button type="submit" class="btn btn-acessar btn-lg fw-bold">ACESSAR</button>
                                    </div>
                                    <div class="text-center">
                                        <a href="/sgi/views/recuperarSenha.php" class="recuperar-senha text-white">Recuperar senha</a>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>