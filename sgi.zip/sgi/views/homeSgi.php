<?php
$action = $_GET['action'] ?? '';
$id     = $_GET['id'] ?? null;
$termo  = $_POST['termo'] ?? '';
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <link rel="shortcut icon" href="static/img/icon.png">
    <meta charset="UTF-8">
    <link rel="stylesheet" href="public/css/style.css">



    <title>SGPD - Início</title>
</head>
<button onclick="window.location.href='loginSgi.php'">Sair</button>

<body>
    <div class="container">
        <div class="nav">
            <h2>SGI</h2>
            <a href="manterProfessores.php">Professores</a>
            <a href="manterDisciplinas.php">Disciplinas</a>
            <a href="manterTurmas.php">Turmas</a>
            <a href="manterHorarios.php">Horários</a>
            <a href="manterAlocacoes.php">Alocações</a>
        </div>
    </div>

</body>

</html>



<body>