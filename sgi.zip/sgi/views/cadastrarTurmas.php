<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['perfil'] !== 'Coordenacao') {
    header("Location: /sgi/index.php");
    exit;
}

$host = "localhost";
$dbname = "sgi";
$username = "root";
$password = "";

$erro = '';
$sucesso = '';

// Buscar dados necessários para os selects
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Buscar cursos ativos
    $stmtCursos = $pdo->prepare("
        SELECT c.idcurso, c.nome_curso 
        FROM curso c 
        JOIN status_curso sc ON c.idstatus_curso = sc.idstatus_curso 
        WHERE sc.nome_stcurso = 'Ativo'
    ");
    $stmtCursos->execute();
    $cursos = $stmtCursos->fetchAll(PDO::FETCH_ASSOC);

    // Buscar turnos
    $stmtTurnos = $pdo->prepare("SELECT idturno, nome_turno FROM turno");
    $stmtTurnos->execute();
    $turnos = $stmtTurnos->fetchAll(PDO::FETCH_ASSOC);

    // Buscar status de turma
    $stmtStatus = $pdo->prepare("SELECT idstatus_turma, nome_stturma FROM status_turma");
    $stmtStatus->execute();
    $status_turmas = $stmtStatus->fetchAll(PDO::FETCH_ASSOC);

    // Buscar grades curriculares
    $stmtGrades = $pdo->prepare("
        SELECT idgrade_curricular, status_grade, dt_vigencia 
        FROM grade_curricular 
        WHERE status_grade = 'Ativo'
    ");
    $stmtGrades->execute();
    $grades = $stmtGrades->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $erro = "Erro de conexão: " . $e->getMessage();
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    try {
        $nome_turma = $_POST["nome_turma"];
        $dt_inicio = $_POST["dt_inicio"];
        $dt_fim = $_POST["dt_fim"];
        $idstatus_turma = $_POST["idstatus_turma"];
        $idturno = $_POST["idturno"];
        $idgrade_curricular = $_POST["idgrade_curricular"];
        $idcurso = $_POST["idcurso"];

        // Validar datas
        if ($dt_inicio >= $dt_fim) {
            $erro = "A data de início deve ser anterior à data de fim.";
        } else {
            // Inserir a turma
            $stmt = $pdo->prepare("
                INSERT INTO turma (nome_turma, dt_inicio, dt_fim, idstatus_turma, idturno, idgrade_curricular, idcurso) 
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([$nome_turma, $dt_inicio, $dt_fim, $idstatus_turma, $idturno, $idgrade_curricular, $idcurso]);

            $sucesso = "Turma cadastrada com sucesso!";
        }
    } catch (PDOException $e) {
        $erro = "Erro ao cadastrar turma: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="/sgi/public/img/icon.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="/sgi/public/css/style.css">
    <title>Cadastro de Turma - SGI</title>
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-white bg-white shadow-sm">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">
                    <img src="/sgi/public/img/logo.png" alt="Logo SGI" class="logo-header">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="btn btn-sair" href="logout.php">
                                <i class="fas fa-sign-out-alt me-1"></i>Sair
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <main class="container-fluid mt-4">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-8 col-xl-6">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h1 class="h3 mb-0 text-white fw-bold">
                        <i class="fas fa-users me-2"></i>Cadastrar Nova Turma
                    </h1>
                    <div class="header-actions">
                        <a href="/sgi/views/listarTurmas.php" class="btn btn-voltar">
                            <i class="fas fa-arrow-left me-1"></i>Voltar
                        </a>
                    </div>
                </div>

                <?php if (!empty($erro)): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <?php echo $erro; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if (!empty($sucesso)): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fas fa-check-circle me-2"></i>
                        <?php echo $sucesso; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <div class="card">
                    <div class="card-header sgi-bg-secondary text-white">
                        <h5 class="mb-0 fw-bold">
                            <i class="fas fa-plus-circle me-2"></i>Dados da Turma
                        </h5>
                    </div>
                    <div class="card-body">
                        <form method="post" id="formCadastro" class="row g-3">
                            <div class="col-12">
                                <label for="nome_turma" class="form-label">
                                    <i class="fas fa-users me-1 text-primary"></i>Nome da Turma:
                                </label>
                                <input type="text" id="nome_turma" name="nome_turma" class="form-control" required 
                                       placeholder="Ex: Turma A - 2024">
                            </div>

                            <div class="col-md-6">
                                <label for="dt_inicio" class="form-label">
                                    <i class="fas fa-calendar-alt me-1 text-primary"></i>Data de Início:
                                </label>
                                <input type="date" id="dt_inicio" name="dt_inicio" class="form-control" required>
                            </div>
                            
                            <div class="col-md-6">
                                <label for="dt_fim" class="form-label">
                                    <i class="fas fa-calendar-times me-1 text-primary"></i>Data de Término:
                                </label>
                                <input type="date" id="dt_fim" name="dt_fim" class="form-control" required>
                            </div>
                            
                            <div class="col-md-6">
                                <label for="idstatus_turma" class="form-label">
                                    <i class="fas fa-info-circle me-1 text-primary"></i>Status da Turma:
                                </label>
                                <select id="idstatus_turma" name="idstatus_turma" class="form-select" required>
                                    <option value="">Selecione o status</option>
                                    <?php foreach ($status_turmas as $status): ?>
                                        <option value="<?php echo $status['idstatus_turma']; ?>">
                                            <?php echo $status['nome_stturma']; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="col-md-6">
                                <label for="idturno" class="form-label">
                                    <i class="fas fa-clock me-1 text-primary"></i>Turno:
                                </label>
                                <select id="idturno" name="idturno" class="form-select" required>
                                    <option value="">Selecione o turno</option>
                                    <?php foreach ($turnos as $turno): ?>
                                        <option value="<?php echo $turno['idturno']; ?>">
                                            <?php echo $turno['nome_turno']; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="col-md-6">
                                <label for="idgrade_curricular" class="form-label">
                                    <i class="fas fa-book me-1 text-primary"></i>Grade Curricular:
                                </label>
                                <select id="idgrade_curricular" name="idgrade_curricular" class="form-select" required>
                                    <option value="">Selecione a grade curricular</option>
                                    <?php foreach ($grades as $grade): ?>
                                        <option value="<?php echo $grade['idgrade_curricular']; ?>">
                                            Grade (Vigência: <?php echo date('d/m/Y', strtotime($grade['dt_vigencia'])); ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="col-md-6">
                                <label for="idcurso" class="form-label">
                                    <i class="fas fa-graduation-cap me-1 text-primary"></i>Curso:
                                </label>
                                <select id="idcurso" name="idcurso" class="form-select" required>
                                    <option value="">Selecione o curso</option>
                                    <?php foreach ($cursos as $curso): ?>
                                        <option value="<?php echo $curso['idcurso']; ?>">
                                            <?php echo $curso['nome_curso']; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="col-12 btn-submit-container">
                                <button type="submit" class="btn-salvar sgi-bg-secondary text-white w-100 py-2 fw-bold">
                                    <i class="fas fa-save me-2"></i>Salvar
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Validação de datas no cliente
        document.getElementById('formCadastro').addEventListener('submit', function(e) {
            const dtInicio = document.getElementById('dt_inicio').value;
            const dtFim = document.getElementById('dt_fim').value;
            
            if (dtInicio && dtFim && dtInicio >= dtFim) {
                e.preventDefault();
                alert('A data de início deve ser anterior à data de término.');
                document.getElementById('dt_inicio').focus();
            }
        });

        // Focar no primeiro campo em desktop
        document.addEventListener('DOMContentLoaded', function() {
            if (window.innerWidth > 768) {
                document.getElementById('nome_turma').focus();
            }
        });
    </script>
</body>
</html>