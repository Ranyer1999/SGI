<?php
$action = $_GET['action'] ?? '';
$id     = $_GET['id'] ?? null;
$termo  = $_POST['termo'] ?? '';
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="/sgi/public/img/icon.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="/sgi/public/css/style.css">
    <title>SGI</title>
</head>
<body>
    <header class="fixed">
        <nav class="navbar navbar-expand-lg navbar-white bg-white shadow-sm">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">
                    <img src="/sgi/public/img/logo.png" alt="Logo SGI" class="logo-header">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="btn btn-sair" href="logout.php">
                                <i class="fas fa-sign-out-alt me-1"></i>Sair
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <main class="container-fluid mt-4">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="card perfil-form mb-4 mx-3">
                    <div class="card-body text-center py-3">
                        <h5 class="card-title mb-0 text-secondary">
                            <i class="fas fa-user-tie me-2"></i>Coordenação
                        </h5>
                    </div>
                </div>

                <div class="card dados-form mx-3">
                    <div class="card-body p-0">
                        <div class="row g-0 text-center">
                            <div class="col-md-4">
                                <a href="listarTurmas.php" class="btn btn-menu w-100 py-4 d-flex flex-column align-items-center justify-content-center">
                                    <i class="fas fa-users fa-3x mb-2"></i>
                                    <span>Turmas</span>
                                </a>
                            </div>
                            <div class="col-md-4">
                                <a href="listarDocentes.php" class="btn btn-menu btn-lg w-100 py-4 d-flex flex-column align-items-center justify-content">
                                    <i class="fas fa-chalkboard-teacher fa-3x mb-2"></i>
                                    <span>Docentes</span>
                                </a>
                            </div>
                            <div class="col-md-4">
                                <a href="listarAlocacoes.php" class="btn btn-menu w-100 py-4 d-flex flex-column align-items-center justify-content-center">
                                    <i class="fas fa-tasks fa-3x mb-2"></i>
                                    <span>Alocações</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>