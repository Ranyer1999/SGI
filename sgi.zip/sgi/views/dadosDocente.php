<?php
session_start();
// Permitir acesso tanto para coordenadores quanto para o próprio professor
if (!isset($_SESSION['usuario'])) {
    header("Location: ../index.php");
    exit;
}

if (!isset($_GET['id'])) {
    header("Location: ../listarDocentes.php");
    exit;
}

$idProfessor = $_GET['id'];

// Verificar se o usuário tem permissão para acessar este perfil
// Coordenadores podem acessar qualquer perfil, professores só podem acessar o próprio
if ($_SESSION['perfil'] === 'Professores' && $_SESSION['id_usuario'] != $idProfessor) {
    header("Location: ../index.php");
    exit;
}

$host = "localhost";
$dbname = "sgi";
$username = "sgiadm";
$password = "sgi#092025";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Buscar dados do professor
    $stmt = $pdo->prepare("SELECT * FROM professor WHERE idprofessor = ?");
    $stmt->execute([$idProfessor]);
    $professor = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$professor) {
        header("Location: ../listarDocentes.php");
        exit;
    }

    // Buscar formações do professor
    $stmtFormacoes = $pdo->prepare("SELECT * FROM formacao_professor WHERE idprofessor = ? ORDER BY ano_conclusao DESC");
    $stmtFormacoes->execute([$idProfessor]);
    $formacoes = $stmtFormacoes->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $erro = "Erro ao carregar perfil: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="/sgi/public/css/style.css">
    <title>Perfil do Docente - <?php echo htmlspecialchars($professor['nome_prof']); ?></title>
</head>

<body>
    <a href="<?php echo ($_SESSION['perfil'] === 'Coordenacao') ? '../listarDocentes.php' : '../homeProfessor.php'; ?>"
        class="voltar-link">← Voltar</a>

    <h1>Perfil do Docente</h1>

    <?php if (isset($erro)): ?>
        <div class="erro"><?php echo $erro; ?></div>
    <?php else: ?>
        <div class="perfil-info">
            <h2><?php echo htmlspecialchars($professor['nome_prof']); ?></h2>
            <p><strong>CPF:</strong> <?php echo htmlspecialchars($professor['cpf']); ?></p>
            <p><strong>Telefone:</strong> <?php echo htmlspecialchars($professor['telefone']); ?></p>
            <p><strong>Data de Nascimento:</strong> <?php echo date('d/m/Y', strtotime($professor['dt_nascimento'])); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($professor['email_prof']); ?></p>
        </div>

        <div class="formacoes-list">
            <h3>Formações</h3>
            <?php if (count($formacoes) > 0): ?>
                <ul>
                    <?php foreach ($formacoes as $formacao): ?>
                        <li>
                            <strong><?php echo htmlspecialchars($formacao['nome_formacao']); ?></strong> -
                            <?php echo htmlspecialchars($formacao['tipo_formacao']); ?> -
                            <?php echo htmlspecialchars($formacao['instituicao']); ?> -
                            Conclusão: <?php echo htmlspecialchars($formacao['ano_conclusao']); ?> -
                            Carga Horária: <?php echo htmlspecialchars($formacao['cargahr_formacao']); ?> horas
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p>Nenhuma formação cadastrada.</p>
            <?php endif; ?>
        </div>

        <div class="acoes">
            <?php if ($_SESSION['perfil'] === 'Coordenacao' || $_SESSION['id_usuario'] == $professor['idusuario']): ?>
                <a href="formacaoDocente.php?id=<?php echo $idProfessor; ?>">Adicionar Formação</a>
            <?php endif; ?>

            <?php if ($_SESSION['perfil'] === 'Professores'): ?>
                <a href="alocacoesDocente.php">Ver Minhas Alocações</a>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</body>

</html>