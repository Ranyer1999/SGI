<?php
session_start();
// Permitir acesso tanto para coordenadores quanto para o próprio professor
if (!isset($_SESSION['usuario'])) {
    header("Location: /sgi/index.php");
    exit;
}

if (!isset($_GET['id'])) {
    header("Location: listarDocentes.php");
    exit;
}

$idProfessor = $_GET['id'];
$host = "localhost";
$dbname = "sgi";
$username = "root";
$password = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Buscar dados do professor
    $stmt = $pdo->prepare("SELECT * FROM professor WHERE idprofessor = ?");
    $stmt->execute([$idProfessor]);
    $professor = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$professor) {
        header("Location: listarDocentes.php");
        exit;
    }

    // Buscar formações do professor
    $stmtFormacoes = $pdo->prepare("SELECT * FROM formacao_professor WHERE idprofessor = ? ORDER BY ano_conclusao DESC");
    $stmtFormacoes->execute([$idProfessor]);
    $formacoes = $stmtFormacoes->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $erro = "Erro ao carregar perfil: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="/sgi/public/img/icon.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="/sgi/public/css/style.css">
    <title>Perfil do Docente - <?php echo $professor['nome_prof']; ?> - SGI</title>
</head>

<body>
    <!-- Cabeçalho Fixo -->
    <header class="fixed-header">
        <nav class="navbar navbar-expand-lg navbar-white bg-white shadow-sm">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">
                    <img src="/sgi/public/img/logo.png" alt="Logo SGI" class="logo-header">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="btn btn-sair" href="logout.php">
                                <i class="fas fa-sign-out-alt me-1"></i>Sair
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <main class="container-fluid main-content">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-10 col-xl-8">
                <div class="d-flex justify-content-between align-items-center mb-4 page-header">
                    <h1 class="h3 mb-0 text-white fw-bold">
                        <i class="fas fa-user-graduate me-2"></i>Perfil do Docente
                    </h1>
                    <div class="header-actions">
                        <?php if ($_SESSION['perfil'] === 'Coordenacao'): ?>
                            <a href="listarDocentes.php" class="btn btn-voltar">
                                <i class="fas fa-arrow-left me-1"></i>Voltar para Lista
                            </a>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if (isset($erro)): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <?php echo $erro; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php else: ?>

                <div class="card profile-card mb-4">
                    <div class="card-header sgi-bg-secondary text-white">
                        <h5 class="mb-0 fw-bold">
                            <i class="fas fa-id-card me-2"></i>Informações Pessoais
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-8">
                                <h3 class="text-primary mb-3"><?php echo $professor['nome_prof']; ?></h3>
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label class="form-label fw-semibold">
                                            <i class="fas fa-id-card me-1 text-muted"></i>CPF:
                                        </label>
                                        <p class="form-control-static"><?php echo $professor['cpf']; ?></p>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label fw-semibold">
                                            <i class="fas fa-phone me-1 text-muted"></i>Telefone:
                                        </label>
                                        <p class="form-control-static"><?php echo $professor['telefone']; ?></p>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label fw-semibold">
                                            <i class="fas fa-birthday-cake me-1 text-muted"></i>Data de Nascimento:
                                        </label>
                                        <p class="form-control-static"><?php echo date('d/m/Y', strtotime($professor['dt_nascimento'])); ?></p>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label fw-semibold">
                                            <i class="fas fa-envelope me-1 text-muted"></i>Email:
                                        </label>
                                        <p class="form-control-static"><?php echo $professor['email_prof']; ?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 text-center">
                                <div class="profile-avatar">
                                    <i class="fas fa-user-graduate fa-5x text-primary"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="card formations-card">
                    <div class="card-header sgi-bg-secondary text-white d-flex justify-content-between align-items-center">
                        <h5 class="mb-0 fw-bold">
                            <i class="fas fa-graduation-cap me-2"></i>Formações Acadêmicas
                        </h5>
                        <?php if ($_SESSION['perfil'] === 'Coordenacao' || $_SESSION['id_usuario'] == $professor['idusuario']): ?>
                            <a href="formacaoDocente.php?id=<?php echo $professor['idprofessor']; ?>" class="btn btn-light btn-sm">
                                <i class="fas fa-plus me-1"></i>Adicionar Formação
                            </a>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <?php if (count($formacoes) > 0): ?>
                            <div class="formations-list">
                                <?php foreach ($formacoes as $formacao): ?>
                                    <div class="formation-item card mb-3">
                                        <div class="card-body">
                                            <div class="d-flex justify-content-between align-items-start">
                                                <div class="flex-grow-1">
                                                    <h6 class="formation-title text-primary mb-2">
                                                        <i class="fas fa-book me-1"></i>
                                                        <?php echo $formacao['nome_formacao']; ?>
                                                    </h6>
                                                    <div class="formation-details">
                                                        <span class="badge bg-primary me-2">
                                                            <i class="fas fa-tag me-1"></i><?php echo $formacao['tipo_formacao']; ?>
                                                        </span>
                                                        <span class="text-muted">
                                                            <i class="fas fa-university me-1"></i><?php echo $formacao['instituicao']; ?>
                                                        </span>
                                                    </div>
                                                    <div class="formation-meta mt-2">
                                                        <small class="text-muted">
                                                            <i class="fas fa-calendar-alt me-1"></i>
                                                            Conclusão: <?php echo $formacao['ano_conclusao']; ?>
                                                        </small>
                                                        <small class="text-muted ms-3">
                                                            <i class="fas fa-clock me-1"></i>
                                                            Carga Horária: <?php echo $formacao['cargahr_formacao']; ?> horas
                                                        </small>
                                                    </div>
                                                </div>
                                                <?php if ($_SESSION['perfil'] === 'Coordenacao' || $_SESSION['id_usuario'] == $professor['idusuario']): ?>
                                                    <div class="formation-actions ms-3">
                                                        <div class="btn-group btn-group-sm">
                                                            <a href="/sgi/crud_operations/editarFormacao.php?id=<?php echo $formacao['idformacao']; ?>" 
                                                               class="btn btn-outline-primary" title="Editar formação">
                                                                <i class="fas fa-edit"></i>
                                                            </a>
                                                            <a href="/sgi/crud_operations/excluirFormacao.php?id=<?php echo $formacao['idformacao']; ?>" 
                                                               class="btn btn-outline-danger" 
                                                               title="Excluir formação"
                                                               onclick="return confirm('Tem certeza que deseja excluir esta formação?')">
                                                                <i class="fas fa-trash"></i>
                                                            </a>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-4">
                                <i class="fas fa-graduation-cap fa-3x text-muted mb-3"></i>
                                <h5 class="text-muted">Nenhuma formação cadastrada</h5>
                                <?php if ($_SESSION['perfil'] === 'Coordenacao' || $_SESSION['id_usuario'] == $professor['idusuario']): ?>
                                    <a href="formacaoDocente.php?id=<?php echo $professor['idprofessor']; ?>" class="btn btn-primary mt-2">
                                        <i class="fas fa-plus me-1"></i>Adicionar Primeira Formação
                                    </a>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Card de Ações Adicionais -->
                <?php if ($_SESSION['perfil'] === 'Professores'): ?>
                    <div class="card mt-4">
                        <div class="card-body text-center">
                            <a href="alocacoesDocente.php" class="btn btn-outline-primary">
                                <i class="fas fa-calendar-alt me-2"></i>Ver Minhas Alocações
                            </a>
                        </div>
                    </div>
                <?php endif; ?>

                <?php endif; ?>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Animação suave para os cards
        document.addEventListener('DOMContentLoaded', function() {
            const cards = document.querySelectorAll('.card');
            cards.forEach((card, index) => {
                card.style.animation = `fadeInUp 0.6s ease ${index * 0.1}s both`;
            });
        });
    </script>
</body>
</html>