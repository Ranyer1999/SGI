<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['perfil'] !== 'Professores') {
    header("Location: /sgi/index.php");
    exit;
}

$idProfessor = $_SESSION['id_perfil'];
$host = "localhost";
        $dbname = "sgi";
        $username = "root";
        $password = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Buscar dados do professor
    $stmtProfessor = $pdo->prepare("SELECT * FROM professor WHERE idprofessor = ?");
    $stmtProfessor->execute([$idProfessor]);
    $professor = $stmtProfessor->fetch(PDO::FETCH_ASSOC);

    // Buscar alocações do professor
    $stmtAlocacoes = $pdo->prepare("
        SELECT 
            a.idalocacao,
            a.dt_alocacao,
            a.periodo_inicio,
            a.periodo_fim,
            t.idturma,
            t.nome_turma,
            c.nome_curso,
            tu.nome_turno,
            s.nome_stalocacao as status_alocacao
        FROM alocacao a
        JOIN turma t ON a.idturma = t.idturma
        JOIN curso c ON t.idcurso = c.idcurso
        JOIN turno tu ON t.idturno = tu.idturno
        JOIN status_alocacao s ON a.idstatus_alocacao = s.idstatus_alocacao
        WHERE a.idprofessor = ?
        ORDER BY a.periodo_inicio DESC, t.nome_turma
    ");
    $stmtAlocacoes->execute([$idProfessor]);
    $alocacoes = $stmtAlocacoes->fetchAll(PDO::FETCH_ASSOC);

    // Contar estatísticas
    $total_alocacoes = count($alocacoes);
    $alocacoes_ativas = 0;
    $alocacoes_encerradas = 0;

    foreach ($alocacoes as $alocacao) {
        if ($alocacao['status_alocacao'] === 'Ativa') {
            $alocacoes_ativas++;
        } elseif ($alocacao['status_alocacao'] === 'Encerrada') {
            $alocacoes_encerradas++;
        }
    }
} catch (PDOException $e) {
    $erro = "Erro ao carregar alocações: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Minhas Alocações - SGI</title>
</head>
<body>
    <h1>Minhas Alocações</h1>

    <button class="btn-voltar" onclick="window.location.href='verDocente.php?id=<?php echo $idProfessor; ?>'">
        Voltar para Meu Perfil
    </button>

    <?php if (isset($erro)): ?>
        <div style="color: red; background-color: #fadbd8; padding: 10px; border-radius: 4px; margin-bottom: 15px;">
            <?php echo $erro; ?>
        </div>
    <?php endif; ?>

    <div class="info-professor">
        <h2><?php echo htmlspecialchars($professor['nome_prof']); ?></h2>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($professor['email_prof']); ?></p>
        <p><strong>Telefone:</strong> <?php echo htmlspecialchars($professor['telefone']); ?></p>
    </div>

    <div class="estatisticas">
        <div class="card-estatistica">
            <div class="numero-estatistica"><?php echo $total_alocacoes; ?></div>
            <div>Total de Alocações</div>
        </div>
        <div class="card-estatistica ativas">
            <div class="numero-estatistica"><?php echo $alocacoes_ativas; ?></div>
            <div>Alocações Ativas</div>
        </div>
        <div class="card-estatistica encerradas">
            <div class="numero-estatistica"><?php echo $alocacoes_encerradas; ?></div>
            <div>Alocações Encerradas</div>
        </div>
    </div>

    <?php if (count($alocacoes) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Turma</th>
                    <th>Curso</th>
                    <th>Turno</th>
                    <th>Data de Alocação</th>
                    <th>Período</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($alocacoes as $alocacao): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($alocacao['nome_turma']); ?></td>
                        <td><?php echo htmlspecialchars($alocacao['nome_curso']); ?></td>
                        <td><?php echo htmlspecialchars($alocacao['nome_turno']); ?></td>
                        <td><?php echo date('d/m/Y', strtotime($alocacao['dt_alocacao'])); ?></td>
                        <td>
                            <?php echo date('d/m/Y', strtotime($alocacao['periodo_inicio'])); ?>
                            a
                            <?php echo date('d/m/Y', strtotime($alocacao['periodo_fim'])); ?>
                        </td>
                        <td>
                            <?php
                            $badge_class = '';
                            if ($alocacao['status_alocacao'] === 'Ativa') {
                                $badge_class = 'badge-ativa';
                            } elseif ($alocacao['status_alocacao'] === 'Encerrada') {
                                $badge_class = 'badge-encerrada';
                            } elseif ($alocacao['status_alocacao'] === 'Cancelada') {
                                $badge_class = 'badge-cancelada';
                            }
                            ?>
                            <span class="badge <?php echo $badge_class; ?>">
                                <?php echo htmlspecialchars($alocacao['status_alocacao']); ?>
                            </span>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <div class="sem-registros">
            <h3>Nenhuma alocação encontrada</h3>
            <p>Você ainda não foi alocado em nenhuma turma.</p>
        </div>
    <?php endif; ?>
</body>

</html>