<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="/sgi/public/img/icon.png">
    <title>Recuperar Senha - SGI</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="/sgi/public/css/style.css">
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-white bg-white shadow-sm">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">
                    <img src="/sgi/public/img/logo.png" alt="Logo SGI" class="logo-header">
                </a>
            </div>
        </nav>
    </header>

    <main class="container flex-grow-1 d-flex-e align-items-center justify-content-center py-5">
        <div class="row justify-content-center w-100">
            <div class="col-12 col-md-8 col-lg-6 col-xl-5">
                <div class="card shadow-lg border-0 recuperar-senha-card">
                    <div class="card-body p-5 text-center">
                        <div class="mb-4">
                            <img src="/sgi/public/img/icon.png" alt="Ícone SGI" class="img-fluid mb-4" style="max-height: 80px;">
                            <h4 class="card-title fw-bold text-secondary mb-4">Recuperação de Senha</h4>
                            
                            <div class="mensagem-recuperacao bg-light p-4 rounded-3">
                                <p class="mb-2">Para alterar a sua senha, procure</p>
                                <p class="mb-2">a Gerência de Tecnologia desta</p>
                                <p class="mb-0">instituição.</p>
                            </div>
                        </div>
                        
                        <div class="d-grid">
                            <button class="btn btn-voltar-login btn-lg" onclick="window.location.href='/sgi/index.php'">
                                <i class="fas fa-arrow-left me-2"></i>Voltar para o login
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>