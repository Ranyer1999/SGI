<?php
session_start();
if (!isset($_SESSION['usuario']) || ($_SESSION['perfil'] !== 'Coordenacao' && $_SESSION['perfil'] !== 'Professores')) {
    header("Location: /sgi/index.php");
    exit;
}

$host = "localhost";
$dbname = "sgi";
$username = "root";
$password = "";

$erro = '';
$sucesso = '';

// Obter ID do professor
$idProfessor = $_GET['id'] ?? ($_SESSION['perfil'] === 'Professores' ? $_SESSION['id_perfil'] : 0);

if (!$idProfessor) {
    header("Location: listarDocentes.php");
    exit;
}

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Buscar dados do professor
    $stmtProfessor = $pdo->prepare("SELECT * FROM professor WHERE idprofessor = ?");
    $stmtProfessor->execute([$idProfessor]);
    $professor = $stmtProfessor->fetch(PDO::FETCH_ASSOC);

    if (!$professor) {
        header("Location: listarDocentes.php");
        exit;
    }

    // Processar formulário
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $nome_formacao = $_POST["nome_formacao"];
        $tipo_formacao = $_POST["tipo_formacao"];
        $instituicao = $_POST["instituicao"];
        $ano_conclusao = $_POST["ano_conclusao"];
        $cargahr_formacao = $_POST["cargahr_formacao"];

        // Validar dados
        if (empty($nome_formacao) || empty($tipo_formacao) || empty($instituicao) || empty($ano_conclusao) || empty($cargahr_formacao)) {
            $erro = "Todos os campos são obrigatórios.";
        } elseif ($ano_conclusao > date('Y') + 5) {
            $erro = "Ano de conclusão inválido.";
        } elseif ($cargahr_formacao <= 0) {
            $erro = "Carga horária deve ser maior que zero.";
        } else {
            // Inserir formação
            $stmt = $pdo->prepare("
                INSERT INTO formacao_professor (nome_formacao, tipo_formacao, instituicao, ano_conclusao, cargahr_formacao, idprofessor) 
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([$nome_formacao, $tipo_formacao, $instituicao, $ano_conclusao, $cargahr_formacao, $idProfessor]);

            $sucesso = "Formação cadastrada com sucesso!";

            // Redirecionar após cadastro bem-sucedido
            if ($_SESSION['perfil'] === 'Coordenacao') {
                header("Refresh: 2; URL=perfilDocente.php?id=" . $idProfessor);
            } else {
                header("Refresh: 2; URL=perfilDocente.php?id=" . $idProfessor);
            }
        }
    }
} catch (PDOException $e) {
    $erro = "Erro de conexão: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="/sgi/public/img/icon.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="/sgi/public/css/style.css">
    <title>Cadastrar Formação - SGI</title>
</head>

<body>
    <!-- Cabeçalho Fixo -->
    <header class="fixed-header">
        <nav class="navbar navbar-expand-lg navbar-white bg-white shadow-sm">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">
                    <img src="/sgi/public/img/logo.png" alt="Logo SGI" class="logo-header">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="btn btn-sair btn-voltar" href="logout.php">
                                <i class="fas fa-sign-out-alt me-1"></i>Sair
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <main class="container-fluid main-content">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-8 col-xl-6">
                <div class="d-flex justify-content-between align-items-center mb-4 page-header">
                    <h1 class="h3 mb-0 text-white fw-bold">
                        <i class="fas fa-graduation-cap me-2"></i>Cadastrar Formação
                    </h1>
                    <div class="header-actions">
                        <?php if ($_SESSION['perfil'] === 'Coordenacao'): ?>
                            <a href="perfilDocente.php?id=<?php echo $idProfessor; ?>" class="btn btn-voltar">
                                <i class="fas fa-arrow-left me-1"></i>Voltar para Perfil
                            </a>
                        <?php else: ?>
                            <a href="perfilDocente.php?id=<?php echo $idProfessor; ?>" class="btn btn-voltar">
                                <i class="fas fa-arrow-left me-1"></i>Voltar para Meu Perfil
                            </a>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Card do Professor -->
                <div class="card professor-card mb-4">
                    <div class="card-body text-center">
                        <div class="professor-avatar mb-3">
                            <i class="fas fa-user-graduate fa-3x text-primary"></i>
                        </div>
                        <h4 class="text-primary mb-1"><?php echo $professor['nome_prof']; ?></h4>
                        <p class="text-muted mb-0">Docente</p>
                    </div>
                </div>

                <?php if (!empty($erro)): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <?php echo $erro; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if (!empty($sucesso)): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fas fa-check-circle me-2"></i>
                        <?php echo $sucesso; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <div class="text-center mt-4">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Redirecionando...</span>
                        </div>
                        <p class="mt-2 text-muted">Redirecionando para o perfil...</p>
                    </div>
                <?php else: ?>

                <!-- Card do Formulário -->
                <div class="card form-card">
                    <div class="card-header sgi-bg-secondary text-white">
                        <h5 class="mb-0 fw-bold">
                            <i class="fas fa-plus-circle me-2"></i>Dados da Formação
                        </h5>
                    </div>
                    <div class="card-body">
                        <form method="post" id="formFormacao" class="row g-3">
                            <div class="col-12">
                                <label for="nome_formacao" class="form-label fw-semibold">
                                    <i class="fas fa-book me-1 text-primary"></i>Título do Curso:
                                </label>
                                <input type="text" id="nome_formacao" name="nome_formacao" class="form-control" 
                                       placeholder="Ex: Licenciatura em Matemática" required>
                            </div>

                            <div class="col-md-6">
                                <label for="tipo_formacao" class="form-label fw-semibold">
                                    <i class="fas fa-tag me-1 text-primary"></i>Tipo de Formação:
                                </label>
                                <select id="tipo_formacao" name="tipo_formacao" class="form-select" required>
                                    <option value="">Selecione o tipo</option>
                                    <option value="Graduação">Graduação</option>
                                    <option value="Especialização">Especialização</option>
                                    <option value="Mestrado">Mestrado</option>
                                    <option value="Doutorado">Doutorado</option>
                                    <option value="Técnico">Curso Técnico</option>
                                    <option value="Extensão">Curso de Extensão</option>
                                    <option value="Aperfeiçoamento">Aperfeiçoamento</option>
                                </select>
                            </div>

                            <div class="col-md-6">
                                <label for="instituicao" class="form-label fw-semibold">
                                    <i class="fas fa-university me-1 text-primary"></i>Instituição:
                                </label>
                                <input type="text" id="instituicao" name="instituicao" class="form-control" 
                                       placeholder="Ex: Universidade Federal" required>
                            </div>

                            <div class="col-md-6">
                                <label for="ano_conclusao" class="form-label fw-semibold">
                                    <i class="fas fa-calendar-alt me-1 text-primary"></i>Ano de Conclusão:
                                </label>
                                <input type="number" id="ano_conclusao" name="ano_conclusao" 
                                       class="form-control" min="1950" max="<?php echo date('Y') + 5; ?>" 
                                       placeholder="Ex: 2020" required>
                                <small class="form-text text-muted">Ano entre 1950 e <?php echo date('Y') + 5; ?></small>
                            </div>

                            <div class="col-md-6">
                                <label for="cargahr_formacao" class="form-label fw-semibold">
                                    <i class="fas fa-clock me-1 text-primary"></i>Carga Horária:
                                </label>
                                <div class="input-group">
                                    <input type="number" id="cargahr_formacao" name="cargahr_formacao" 
                                           class="form-control" min="1" placeholder="Ex: 120" required>
                                    <span class="input-group-text">horas</span>
                                </div>
                                <small class="form-text text-muted">Carga horária total do curso</small>
                            </div>

                            <div class="col-12 mt-4">
                                <button type="submit" class="btn btn-primary w-100 py-3 fw-bold">
                                    <i class="fas fa-save me-2"></i>Cadastrar Formação
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <?php endif; ?>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Validação em tempo real
        document.getElementById('formFormacao').addEventListener('submit', function(e) {
            const anoConclusao = document.getElementById('ano_conclusao').value;
            const cargaHoraria = document.getElementById('cargahr_formacao').value;
            const currentYear = new Date().getFullYear();
            
            if (anoConclusao && (anoConclusao < 1950 || anoConclusao > currentYear + 5)) {
                e.preventDefault();
                alert('Ano de conclusão deve estar entre 1950 e ' + (currentYear + 5));
                document.getElementById('ano_conclusao').focus();
                return;
            }
            
            if (cargaHoraria && cargaHoraria <= 0) {
                e.preventDefault();
                alert('Carga horária deve ser maior que zero');
                document.getElementById('cargahr_formacao').focus();
                return;
            }
        });

        // Focar no primeiro campo
        document.addEventListener('DOMContentLoaded', function() {
            if (window.innerWidth > 768) {
                document.getElementById('nome_formacao').focus();
            }
        });

        // Melhorar UX para mobile
        document.querySelectorAll('.form-control').forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.classList.add('focused');
            });
            
            input.addEventListener('blur', function() {
                this.parentElement.classList.remove('focused');
            });
        });
    </script>
</body>
</html>