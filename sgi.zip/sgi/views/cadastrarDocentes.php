<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['perfil'] !== 'Coordenacao') {
    header("Location: /sgi/index.php");
    exit;
}

$erro = '';
$sucesso = '';

// Função para validar a força da senha
function validarSenha($senha)
{
    // Verificar se tem pelo menos uma letra maiúscula
    if (!preg_match('/[A-Z]/', $senha)) {
        return "A senha deve conter pelo menos uma letra maiúscula";
    }

    // Verificar se tem pelo menos um número
    if (!preg_match('/[0-9]/', $senha)) {
        return "A senha deve conter pelo menos um número";
    }

    // Verificar se tem pelo menos um caractere especial
    if (!preg_match('/[^a-zA-Z0-9]/', $senha)) {
        return "A senha deve conter pelo menos um caractere especial";
    }

    // Verificar comprimento mínimo
    if (strlen($senha) < 6) {
        return "A senha deve ter pelo menos 6 caracteres";
    }

    return true;
}

// Função para validar CPF
function validarCPF($cpf)
{
    // Remove caracteres não numéricos
    $cpf = preg_replace('/[^0-9]/', '', $cpf);

    // Verifica se foi informado todos os digitos
    if (strlen($cpf) != 11) {
        return false;
    }

    // Verifica se foi informada uma sequência de digitos repetidos
    if (preg_match('/(\d)\1{10}/', $cpf)) {
        return false;
    }

    // Faz o cálculo para validar o CPF
    for ($t = 9; $t < 11; $t++) {
        for ($d = 0, $c = 0; $c < $t; $c++) {
            $d += $cpf[$c] * (($t + 1) - $c);
        }
        $d = ((10 * $d) % 11) % 10;
        if ($cpf[$c] != $d) {
            return false;
        }
    }
    return true;
}

// Função para validar telefone
function validarTelefone($telefone)
{
    // Remove caracteres não numéricos
    $telefone = preg_replace('/[^0-9]/', '', $telefone);

    // Verifica se é um telefone válido (10 ou 11 dígitos)
    if (strlen($telefone) < 10 || strlen($telefone) > 11) {
        return false;
    }

    return true;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $host = "localhost";
    $dbname = "sgi";
    $username = "root";
    $password = "";

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $nome_prof = $_POST["nome_prof"];
        $cpf = $_POST["cpf"];
        $telefone = $_POST["telefone"];
        $dt_nascimento = $_POST["dt_nascimento"];
        $email_prof = $_POST["email_prof"];
        $senha_prof = $_POST["senha_prof"];

        // Validar CPF
        if (!validarCPF($cpf)) {
            $erro = "CPF inválido.";
        }
        // Validar telefone
        else if (!validarTelefone($telefone)) {
            $erro = "Telefone inválido.";
        }
        // Validar a senha
        else {
            $validacaoSenha = validarSenha($senha_prof);
            if ($validacaoSenha !== true) {
                $erro = $validacaoSenha;
            } else {
                // Verificar se o email já existe
                $stmtVerifica = $pdo->prepare("SELECT idusuario FROM usuario WHERE user_login = ?");
                $stmtVerifica->execute([$email_prof]);

                if ($stmtVerifica->fetch()) {
                    $erro = "Este email já está cadastrado no sistema.";
                } else {
                    // Verificar si o CPF já existe
                    $stmtVerificaCPF = $pdo->prepare("SELECT idprofessor FROM professor WHERE cpf = ?");
                    $stmtVerificaCPF->execute([preg_replace('/[^0-9]/', '', $cpf)]);

                    if ($stmtVerificaCPF->fetch()) {
                        $erro = "Este CPF já está cadastrado no sistema.";
                    } else {
                        // CORREÇÃO: Remover a subconsulta problemática
                        // Buscar o ID do grupo de professores usando JOIN
                        $stmtGrupo = $pdo->prepare("
                            SELECT idgrupo_acesso 
                            FROM grupo_acesso 
                            WHERE nome_grupo = 'Professores'
                        ");
                        $stmtGrupo->execute();
                        $grupo = $stmtGrupo->fetch(PDO::FETCH_ASSOC);

                        if (!$grupo) {
                            $erro = "Grupo de acesso 'Professores' não encontrado.";
                        } else {
                            $idGrupo = $grupo['idgrupo_acesso'];

                            // Primeiro, criar um usuário para o professor
                            $stmtUsuario = $pdo->prepare("
                                INSERT INTO usuario (idgrupo_acesso, user_login, senha, dt_criacao) 
                                VALUES (?, ?, ?, NOW())
                            ");
                            $stmtUsuario->execute([$idGrupo, $email_prof, $senha_prof]);
                            $idUsuario = $pdo->lastInsertId();

                            // Inserir o professor
                            $stmtProfessor = $pdo->prepare("
                                INSERT INTO professor (nome_prof, cpf, telefone, dt_nascimento, email_prof, idusuario) 
                                VALUES (?, ?, ?, ?, ?, ?)
                            ");
                            $stmtProfessor->execute([
                                $nome_prof,
                                preg_replace('/[^0-9]/', '', $cpf),
                                preg_replace('/[^0-9]/', '', $telefone),
                                $dt_nascimento,
                                $email_prof,
                                $idUsuario
                            ]);
                            $idProfessor = $pdo->lastInsertId();

                            $sucesso = "Professor cadastrado com sucesso!";
                        }
                    }
                }
            }
        }
    } catch (PDOException $e) {
        $erro = "Erro ao cadastrar professor: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="/sgi/public/img/icon.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="/sgi/public/css/style.css">
    <title>Cadastro de Professor - SGI</title>
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-white bg-white shadow-sm">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">
                    <img src="/sgi/public/img/logo.png" alt="Logo SGI" class="logo-header">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="btn btn-sair" href="logout.php">
                                <i class="fas fa-sign-out-alt me-1"></i>Sair
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <main class="container-fluid mt-4">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-8 col-xl-6">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h1 class="h3 mb-0 text-white">
                        <i class="fas fa-chalkboard-teacher me-2 text-white"></i>Cadastro de Docentes
                    </h1>
                    <div class="header-actions">
                        <a href="/sgi/views/listarDocentes.php" class="btn btn-voltar">
                            <i class="fas fa-arrow-left me-1"></i>Voltar
                        </a>
                    </div>
                </div>

                <?php if (!empty($erro)): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <?php echo $erro; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if (!empty($sucesso)): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fas fa-check-circle me-2"></i>
                        <?php echo $sucesso; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <div class="card">
                    <div class="card-header sgi-bg-secondary text-white">
                        <h5 class="mb-0">
                            <i class="fas fa-user-plus me-2"></i>Novo Professor
                        </h5>
                    </div>
                    <div class="card-body">
                        <form method="post" id="formCadastro" class="row g-3">
                            <div class="col-md-6">
                                <label for="nome_prof" class="form-label fw-semibold">
                                    <i class="fas fa-user me-1"></i>Nome Completo:
                                </label>
                                <input type="text" id="nome_prof" name="nome_prof" class="form-control" 
                                    value="<?php echo isset($_POST['nome_prof']) ? htmlspecialchars($_POST['nome_prof']) : ''; ?>" 
                                    required>
                            </div>

                            <div class="col-md-6">
                                <label for="cpf" class="form-label fw-semibold">
                                    <i class="fas fa-id-card me-1"></i>CPF:
                                </label>
                                <input type="text" id="cpf" name="cpf" class="form-control" 
                                    placeholder="000.000.000-00" 
                                    value="<?php echo isset($_POST['cpf']) ? htmlspecialchars($_POST['cpf']) : ''; ?>" 
                                    required maxlength="14">
                                <div id="cpfErro" class="invalid-feedback"></div>
                            </div>

                            <div class="col-md-6">
                                <label for="telefone" class="form-label fw-semibold">
                                    <i class="fas fa-phone me-1"></i>Telefone:
                                </label>
                                <input type="text" id="telefone" name="telefone" class="form-control" 
                                    placeholder="(00) 00000-0000" 
                                    value="<?php echo isset($_POST['telefone']) ? htmlspecialchars($_POST['telefone']) : ''; ?>" 
                                    required maxlength="15">
                                <div id="telefoneErro" class="invalid-feedback"></div>
                            </div>

                            <div class="col-md-6">
                                <label for="dt_nascimento" class="form-label fw-semibold">
                                    <i class="fas fa-calendar-alt me-1"></i>Data de Nascimento:
                                </label>
                                <input type="date" id="dt_nascimento" name="dt_nascimento" class="form-control" 
                                    value="<?php echo isset($_POST['dt_nascimento']) ? htmlspecialchars($_POST['dt_nascimento']) : ''; ?>" 
                                    required>
                            </div>

                            <div class="col-md-6">
                                <label for="email_prof" class="form-label fw-semibold">
                                    <i class="fas fa-envelope me-1"></i>Email:
                                </label>
                                <input type="email" id="email_prof" name="email_prof" class="form-control" 
                                    value="<?php echo isset($_POST['email_prof']) ? htmlspecialchars($_POST['email_prof']) : ''; ?>" 
                                    required>
                            </div>

                            <div class="col-md-6">
                                <label for="senha_prof" class="form-label fw-semibold">
                                    <i class="fas fa-lock me-1"></i>Senha:
                                </label>
                                <input type="password" id="senha_prof" name="senha_prof" class="form-control" 
                                    required minlength="6">
                                <div class="form-text">
                                    <small>A senha deve conter pelo menos:</small>
                                    <ul class="small mb-0 mt-1">
                                        <li id="req1">6 caracteres</li>
                                        <li id="req2">1 letra maiúscula</li>
                                        <li id="req3">1 número</li>
                                        <li id="req4">1 caractere especial (ex: @, #, $, etc.)</li>
                                    </ul>
                                </div>
                            </div>

                            <div class="col-12 mt-4">
                                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                    <button type="submit" class="btn btn-cadastrar">
                                        <i class="fas fa-save me-2"></i>Cadastrar Professor
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Aplicar máscara ao CPF
        function mascaraCPF(cpf) {
            cpf = cpf.replace(/\D/g, "");
            cpf = cpf.replace(/(\d{3})(\d)/, "$1.$2");
            cpf = cpf.replace(/(\d{3})(\d)/, "$1.$2");
            cpf = cpf.replace(/(\d{3})(\d{1,2})$/, "$1-$2");
            return cpf;
        }

        // Aplicar máscara ao telefone
        function mascaraTelefone(telefone) {
            telefone = telefone.replace(/\D/g, "");
            telefone = telefone.replace(/^(\d{2})(\d)/g, "($1) $2");
            telefone = telefone.replace(/(\d)(\d{4})$/, "$1-$2");
            return telefone;
        }

        // Validar CPF com algoritmo
        function validarCPF(cpf) {
            cpf = cpf.replace(/\D/g, '');

            if (cpf.length !== 11) return false;

            // Verifica se todos os dígitos são iguais
            if (/^(\d)\1+$/.test(cpf)) return false;

            // Validação do algoritmo do CPF
            let soma = 0;
            let resto;

            for (let i = 1; i <= 9; i++)
                soma += parseInt(cpf.substring(i - 1, i)) * (11 - i);
            resto = (soma * 10) % 11;

            if ((resto === 10) || (resto === 11)) resto = 0;
            if (resto !== parseInt(cpf.substring(9, 10))) return false;

            soma = 0;
            for (let i = 1; i <= 10; i++)
                soma += parseInt(cpf.substring(i - 1, i)) * (12 - i);
            resto = (soma * 10) % 11;

            if ((resto === 10) || (resto === 11)) resto = 0;
            if (resto !== parseInt(cpf.substring(10, 11))) return false;

            return true;
        }

        // Validar telefone
        function validarTelefone(telefone) {
            telefone = telefone.replace(/\D/g, '');
            return telefone.length >= 10 && telefone.length <= 11;
        }

        // Elementos do DOM
        const cpfInput = document.getElementById('cpf');
        const telefoneInput = document.getElementById('telefone');
        const cpfErro = document.getElementById('cpfErro');
        const telefoneErro = document.getElementById('telefoneErro');
        const form = document.getElementById('formCadastro');

        // Aplicar máscaras durante a digitação
        cpfInput.addEventListener('input', function() {
            this.value = mascaraCPF(this.value);

            // Validar em tempo real
            if (this.value.length === 14) {
                if (validarCPF(this.value)) {
                    this.classList.remove('is-invalid');
                    this.classList.add('is-valid');
                    cpfErro.textContent = '';
                } else {
                    this.classList.remove('is-valid');
                    this.classList.add('is-invalid');
                    cpfErro.textContent = 'CPF inválido';
                }
            } else {
                this.classList.remove('is-valid', 'is-invalid');
                cpfErro.textContent = '';
            }
        });

        telefoneInput.addEventListener('input', function() {
            this.value = mascaraTelefone(this.value);

            // Validar em tempo real
            if (this.value.length === 15) {
                if (validarTelefone(this.value)) {
                    this.classList.remove('is-invalid');
                    this.classList.add('is-valid');
                    telefoneErro.textContent = '';
                } else {
                    this.classList.remove('is-valid');
                    this.classList.add('is-invalid');
                    telefoneErro.textContent = 'Telefone inválido';
                }
            } else {
                this.classList.remove('is-valid', 'is-invalid');
                telefoneErro.textContent = '';
            }
        });

        // Validação antes do envio do formulário
        form.addEventListener('submit', function(e) {
            let cpfValido = validarCPF(cpfInput.value);
            let telefoneValido = validarTelefone(telefoneInput.value);
            let formularioValido = true;

            if (!cpfValido) {
                cpfInput.classList.add('is-invalid');
                cpfErro.textContent = 'CPF inválido';
                formularioValido = false;
            }

            if (!telefoneValido) {
                telefoneInput.classList.add('is-invalid');
                telefoneErro.textContent = 'Telefone inválido';
                formularioValido = false;
            }

            if (!formularioValido) {
                e.preventDefault();
            }
        });

        // Validação em tempo real da senha
        document.getElementById('senha_prof').addEventListener('input', function() {
            const senha = this.value;
            const requisitos = {
                maiuscula: /[A-Z]/.test(senha),
                numero: /[0-9]/.test(senha),
                especial: /[^a-zA-Z0-9]/.test(senha),
                comprimento: senha.length >= 6
            };

            // Atualizar visualmente os requisitos
            document.getElementById('req1').style.color = requisitos.comprimento ? 'green' : 'red';
            document.getElementById('req2').style.color = requisitos.maiuscula ? 'green' : 'red';
            document.getElementById('req3').style.color = requisitos.numero ? 'green' : 'red';
            document.getElementById('req4').style.color = requisitos.especial ? 'green' : 'red';

            // Validar campo
            if (senha.length >= 6 && requisitos.maiuscula && requisitos.numero && requisitos.especial) {
                this.classList.remove('is-invalid');
                this.classList.add('is-valid');
            } else {
                this.classList.remove('is-valid');
                if (senha.length > 0) {
                    this.classList.add('is-invalid');
                }
            }
        });
    </script>
</body>
</html>