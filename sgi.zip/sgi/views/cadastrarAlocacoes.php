<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['perfil'] !== 'Coordenacao') {
    header("Location: /sgi/index.php");
    exit;
}

$host = "localhost";
$dbname = "sgi";
$username = "root";
$password = "";

$erro = '';
$sucesso = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Buscar professores ativos
    $stmtProfessores = $pdo->prepare("
        SELECT idprofessor, nome_prof 
        FROM professor 
        ORDER BY nome_prof
    ");
    $stmtProfessores->execute();
    $professores = $stmtProfessores->fetchAll(PDO::FETCH_ASSOC);

    // Buscar turmas ativas
    $stmtTurmas = $pdo->prepare("
        SELECT t.idturma, t.nome_turma, c.nome_curso 
        FROM turma t
        JOIN curso c ON t.idcurso = c.idcurso
        JOIN status_turma st ON t.idstatus_turma = st.idstatus_turma
        WHERE st.nome_stturma = 'Aberta'
        ORDER BY t.nome_turma
    ");
    $stmtTurmas->execute();
    $turmas = $stmtTurmas->fetchAll(PDO::FETCH_ASSOC);

    // Buscar status de alocação
    $stmtStatus = $pdo->prepare("SELECT idstatus_alocacao, nome_stalocacao FROM status_alocacao");
    $stmtStatus->execute();
    $status_alocacoes = $stmtStatus->fetchAll(PDO::FETCH_ASSOC);

    // Buscar componentes disponíveis
    $stmtComponentes = $pdo->prepare("
        SELECT idcomponente, nome_componente, cargahr_comp 
        FROM componente 
        ORDER BY nome_componente
    ");
    $stmtComponentes->execute();
    $componentes = $stmtComponentes->fetchAll(PDO::FETCH_ASSOC);

    // Processar o formulário quando enviado
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $idprofessor = $_POST["idprofessor"];
        $idturma = $_POST["idturma"];
        $idstatus_alocacao = $_POST["idstatus_alocacao"];
        $periodo_inicio = $_POST["periodo_inicio"];
        $periodo_fim = $_POST["periodo_fim"];
        $idcomponente = $_POST["idcomponente"];

        // Validar datas
        if ($periodo_inicio >= $periodo_fim) {
            $erro = "A data de início deve ser anterior à data de fim.";
        } else {
            // Verificar se já existe uma alocação ativa para este professor nesta turma e componente
            $stmtVerifica = $pdo->prepare("
                SELECT idalocacao 
                FROM alocacao 
                WHERE idprofessor = ? AND idturma = ? AND idcomponente = ?
                AND idstatus_alocacao = (SELECT idstatus_alocacao FROM status_alocacao WHERE nome_stalocacao = 'Ativa')
            ");
            $stmtVerifica->execute([$idprofessor, $idturma, $idcomponente]);

            if ($stmtVerifica->fetch()) {
                $erro = "Este professor já está alocado para esta turma e componente com status ativo.";
            } else {
                // Inserir a alocação
                $stmt = $pdo->prepare("
                    INSERT INTO alocacao (dt_alocacao, idstatus_alocacao, idprofessor, idturma, periodo_inicio, periodo_fim, idcomponente) 
                    VALUES (CURDATE(), ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([$idstatus_alocacao, $idprofessor, $idturma, $periodo_inicio, $periodo_fim, $idcomponente]);

                $sucesso = "Alocação cadastrada com sucesso!";
            }
        }
    }
} catch (PDOException $e) {
    $erro = "Erro de conexão: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="/sgi/public/img/icon.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="/sgi/public/css/style.css">
    <title>Cadastrar Alocação - SGI</title>
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-white bg-white shadow-sm">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">
                    <img src="/sgi/public/img/logo.png" alt="Logo SGI" class="logo-header">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="btn btn-sair" href="logout.php">
                                <i class="fas fa-sign-out-alt me-1"></i>Sair
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <main class="container-fluid mt-4">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-8 col-xl-6">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h1 class="h3 mb-0 text-white">
                        <i class="fas fa-plus-circle me-2 text-white"></i>Cadastrar Alocação
                    </h1>
                    <div class="header-actions">
                        <a href="listarAlocacoes.php" class="btn btn-voltar">
                            <i class="fas fa-arrow-left me-1"></i>Voltar
                        </a>
                    </div>
                </div>

                <?php if (!empty($erro)): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <?php echo $erro; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if (!empty($sucesso)): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fas fa-check-circle me-2"></i>
                        <?php echo $sucesso; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <div class="card">
                    <div class="card-header sgi-text-secondary text-white">
                        <h5 class="mb-0">
                            <i class="fas fa-tasks me-2"></i>Nova Alocação
                        </h5>
                    </div>
                    <div class="card-body">
                        <form method="post" class="row g-3">
                            <div class="col-md-6">
                                <label for="idprofessor" class="form-label fw-semibold">
                                    <i class="fas fa-user-tie me-1"></i>Professor:
                                </label>
                                <select id="idprofessor" name="idprofessor" class="form-select" required>
                                    <option value="">Selecione o professor</option>
                                    <?php foreach ($professores as $professor): ?>
                                        <option value="<?php echo $professor['idprofessor']; ?>" 
                                            <?php echo (isset($_POST['idprofessor']) && $_POST['idprofessor'] == $professor['idprofessor']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($professor['nome_prof']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="col-md-6">
                                <label for="idturma" class="form-label fw-semibold">
                                    <i class="fas fa-users me-1"></i>Turma:
                                </label>
                                <select id="idturma" name="idturma" class="form-select" required>
                                    <option value="">Selecione a turma</option>
                                    <?php foreach ($turmas as $turma): ?>
                                        <option value="<?php echo $turma['idturma']; ?>"
                                            <?php echo (isset($_POST['idturma']) && $_POST['idturma'] == $turma['idturma']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($turma['nome_turma']); ?> - <?php echo htmlspecialchars($turma['nome_curso']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="col-md-6">
                                <label for="idcomponente" class="form-label fw-semibold">
                                    <i class="fas fa-book me-1"></i>Componente Curricular:
                                </label>
                                <select id="idcomponente" name="idcomponente" class="form-select" required>
                                    <option value="">Selecione o componente</option>
                                    <?php foreach ($componentes as $componente): ?>
                                        <option value="<?php echo $componente['idcomponente']; ?>"
                                            <?php echo (isset($_POST['idcomponente']) && $_POST['idcomponente'] == $componente['idcomponente']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($componente['nome_componente']); ?> 
                                            (<?php echo $componente['cargahr_comp']; ?>h)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="col-md-6">
                                <label for="idstatus_alocacao" class="form-label fw-semibold">
                                    <i class="fas fa-info-circle me-1"></i>Status da Alocação:
                                </label>
                                <select id="idstatus_alocacao" name="idstatus_alocacao" class="form-select" required>
                                    <option value="">Selecione o status</option>
                                    <?php foreach ($status_alocacoes as $status): ?>
                                        <option value="<?php echo $status['idstatus_alocacao']; ?>"
                                            <?php echo (isset($_POST['idstatus_alocacao']) && $_POST['idstatus_alocacao'] == $status['idstatus_alocacao']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($status['nome_stalocacao']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="col-md-6">
                                <label for="periodo_inicio" class="form-label fw-semibold">
                                    <i class="fas fa-calendar-alt me-1"></i>Período de Início:
                                </label>
                                <input type="date" id="periodo_inicio" name="periodo_inicio" 
                                    class="form-control" 
                                    value="<?php echo isset($_POST['periodo_inicio']) ? htmlspecialchars($_POST['periodo_inicio']) : ''; ?>" 
                                    required>
                            </div>

                            <div class="col-md-6">
                                <label for="periodo_fim" class="form-label fw-semibold">
                                    <i class="fas fa-calendar-check me-1"></i>Período de Término:
                                </label>
                                <input type="date" id="periodo_fim" name="periodo_fim" 
                                    class="form-control" 
                                    value="<?php echo isset($_POST['periodo_fim']) ? htmlspecialchars($_POST['periodo_fim']) : ''; ?>" 
                                    required>
                            </div>

                            <div class="col-12 mt-4">
                                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                    <button type="submit" class="btn btn-cadastrar">
                                        <i class="fas fa-save me-2"></i>Salvar
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>