<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['perfil'] !== 'Coordenacao') {
    header("Location: /sgi/index.php");
    exit;
}

$host = "localhost";
$dbname = "sgi";
$username = "sgiadm";
$password = "sgi#092025";

$erro = '';
$sucesso = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Buscar professores ativos
    $stmtProfessores = $pdo->prepare("
        SELECT idprofessor, nome_prof 
        FROM professor 
        ORDER BY nome_prof
    ");
    $stmtProfessores->execute();
    $professores = $stmtProfessores->fetchAll(PDO::FETCH_ASSOC);

    // Buscar turmas ativas
    $stmtTurmas = $pdo->prepare("
        SELECT t.idturma, t.nome_turma, c.nome_curso 
        FROM turma t
        JOIN curso c ON t.idcurso = c.idcurso
        JOIN status_turma st ON t.idstatus_turma = st.idstatus_turma
        WHERE st.nome_stturma = 'Aberta'
        ORDER BY t.nome_turma
    ");
    $stmtTurmas->execute();
    $turmas = $stmtTurmas->fetchAll(PDO::FETCH_ASSOC);

    // Buscar status de alocação
    $stmtStatus = $pdo->prepare("SELECT idstatus_alocacao, nome_stalocacao FROM status_alocacao");
    $stmtStatus->execute();
    $status_alocacoes = $stmtStatus->fetchAll(PDO::FETCH_ASSOC);

    // Processar o formulário quando enviado
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $idprofessor = $_POST["idprofessor"];
        $idturma = $_POST["idturma"];
        $idstatus_alocacao = $_POST["idstatus_alocacao"];
        $periodo_inicio = $_POST["periodo_inicio"];
        $periodo_fim = $_POST["periodo_fim"];

        // Validar datas
        if ($periodo_inicio >= $periodo_fim) {
            $erro = "A data de início deve ser anterior à data de fim.";
        } else {
            // Verificar se já existe uma alocação ativa para este professor nesta turma
            $stmtVerifica = $pdo->prepare("
                SELECT idalocacao 
                FROM alocacao 
                WHERE idprofessor = ? AND idturma = ? 
                AND idstatus_alocacao = (SELECT idstatus_alocacao FROM status_alocacao WHERE nome_stalocacao = 'Ativa')
            ");
            $stmtVerifica->execute([$idprofessor, $idturma]);

            if ($stmtVerifica->fetch()) {
                $erro = "Este professor já está alocado para esta turma com status ativo.";
            } else {
                // Inserir a alocação
                $stmt = $pdo->prepare("
                    INSERT INTO alocacao (dt_alocacao, idstatus_alocacao, idprofessor, idturma, periodo_inicio, periodo_fim) 
                    VALUES (CURDATE(), ?, ?, ?, ?, ?)
                ");
                $stmt->execute([$idstatus_alocacao, $idprofessor, $idturma, $periodo_inicio, $periodo_fim]);

                $sucesso = "Alocação cadastrada com sucesso!";
            }
        }
    }
} catch (PDOException $e) {
    $erro = "Erro de conexão: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Cadastrar Alocação</title>
</head>

<body>
    <h1>Cadastrar Alocação</h1>
    <a href="homeCoordenacao.php">Voltar para Home</a>
    <a href="listarAlocacoes.php">Ver Alocações Existentes</a>

    <?php if (!empty($erro)): ?>
        <div class="erro"><?php echo $erro; ?></div>
    <?php endif; ?>

    <?php if (!empty($sucesso)): ?>
        <div class="sucesso"><?php echo $sucesso; ?></div>
    <?php endif; ?>

    <form method="post">
        <div>
            <label for="idprofessor">Professor:</label>
            <select id="idprofessor" name="idprofessor" required>
                <option value="">Selecione o professor</option>
                <?php foreach ($professores as $professor): ?>
                    <option value="<?php echo $professor['idprofessor']; ?>">
                        <?php echo $professor['nome_prof']; ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div>
            <label for="idturma">Turma:</label>
            <select id="idturma" name="idturma" required>
                <option value="">Selecione a turma</option>
                <?php foreach ($turmas as $turma): ?>
                    <option value="<?php echo $turma['idturma']; ?>">
                        <?php echo $turma['nome_turma']; ?> - <?php echo $turma['nome_curso']; ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div>
            <label for="idstatus_alocacao">Status da Alocação:</label>
            <select id="idstatus_alocacao" name="idstatus_alocacao" required>
                <option value="">Selecione o status</option>
                <?php foreach ($status_alocacoes as $status): ?>
                    <option value="<?php echo $status['idstatus_alocacao']; ?>">
                        <?php echo $status['nome_stalocacao']; ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div>
            <label for="periodo_inicio">Período de Início:</label>
            <input type="date" id="periodo_inicio" name="periodo_inicio" required>
        </div>

        <div>
            <label for="periodo_fim">Período de Término:</label>
            <input type="date" id="periodo_fim" name="periodo_fim" required>
        </div>

        <input type="submit" value="Cadastrar Alocação">
    </form>
</body>

</html>