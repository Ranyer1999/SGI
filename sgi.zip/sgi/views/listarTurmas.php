<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['perfil'] !== 'Coordenacao') {
    header("Location: /sgi/index.php");
    exit;
}

$host = "localhost";
$dbname = "sgi";
$username = "root";
$password = "";

// Parâmetros de filtro
$filtro_turma = $_GET['turma'] ?? '';
$filtro_curso = $_GET['curso'] ?? '';
$filtro_status = $_GET['status'] ?? '';
$filtro_turno = $_GET['turno'] ?? '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Construir query com filtros
    $sql = "
        SELECT 
            t.*,
            c.nome_curso,
            tu.nome_turno,
            st.nome_stturma,
            g.dt_vigencia
        FROM turma t
        JOIN curso c ON t.idcurso = c.idcurso
        JOIN turno tu ON t.idturno = tu.idturno
        JOIN status_turma st ON t.idstatus_turma = st.idstatus_turma
        JOIN grade_curricular g ON t.idgrade_curricular = g.idgrade_curricular
        WHERE 1=1
    ";
    
    $params = [];

    if (!empty($filtro_turma)) {
        $sql .= " AND t.nome_turma LIKE ?";
        $params[] = "%$filtro_turma%";
    }

    if (!empty($filtro_curso)) {
        $sql .= " AND c.nome_curso LIKE ?";
        $params[] = "%$filtro_curso%";
    }

    if (!empty($filtro_status)) {
        $sql .= " AND st.nome_stturma = ?";
        $params[] = $filtro_status;
    }

    if (!empty($filtro_turno)) {
        $sql .= " AND tu.nome_turno = ?";
        $params[] = $filtro_turno;
    }

    $sql .= " ORDER BY t.dt_inicio DESC, t.nome_turma";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $turmas = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Buscar status para o filtro
    $stmtStatus = $pdo->prepare("SELECT nome_stturma FROM status_turma");
    $stmtStatus->execute();
    $status_lista = $stmtStatus->fetchAll(PDO::FETCH_COLUMN);

    // Buscar turnos para o filtro
    $stmtTurnos = $pdo->prepare("SELECT nome_turno FROM turno");
    $stmtTurnos->execute();
    $turnos_lista = $stmtTurnos->fetchAll(PDO::FETCH_COLUMN);

} catch (PDOException $e) {
    $erro = "Erro ao carregar turmas: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="/sgi/public/img/icon.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="/sgi/public/css/style.css">
    <title>Lista de Turmas - SGI</title>
</head>

<body>
    <header class="fixed">
        <nav class="navbar navbar-expand-lg navbar-white bg-white shadow-sm">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">
                    <img src="/sgi/public/img/logo.png" alt="Logo SGI" class="logo-header">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="btn btn-sair" href="logout.php">
                                <i class="fas fa-sign-out-alt me-1"></i>Sair
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <!-- Conteúdo Principal -->
    <main class="container-fluid main-content">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-10 col-xl-8">
                <!-- Cabeçalho da Página -->
                <div class="d-flex justify-content-between align-items-center mb-4 page-header">
                    <h1 class="h3 mb-0 text-white fw-bold">
                        <i class="fas fa-users me-2"></i>Turmas Cadastradas
                    </h1>
                    <div class="header-actions">
                        <a href="/sgi/views/homeCoordenacao.php" class="btn btn-voltar me-2">
                            <i class="fas fa-home me-1"></i>Home
                        </a>
                        <a href="/sgi/views/cadastrarTurmas.php" class="btn btn-primary">
                            <i class="fas fa-plus me-1"></i>Nova Turma
                        </a>
                    </div>
                </div>

                <?php if (isset($erro)): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <?php echo $erro; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <!-- Card de Filtros -->
                <div class="card filter-card mb-4">
                    <div class="card-header sgi-bg-secondary text-white">
                        <h5 class="mb-0 fw-bold">
                            <i class="fas fa-filter me-2"></i>Filtrar Turmas
                        </h5>
                    </div>
                    <div class="card-body">
                        <form method="get" class="row g-3">
                            <div class="col-md-6 col-lg-3">
                                <label for="turma" class="form-label">
                                    <i class="fas fa-users me-1 text-primary"></i>Nome da Turma:
                                </label>
                                <input type="text" id="turma" name="turma" class="form-control" 
                                       value="<?php echo htmlspecialchars($filtro_turma); ?>" 
                                       placeholder="Digite o nome da turma">
                            </div>

                            <div class="col-md-6 col-lg-3">
                                <label for="curso" class="form-label">
                                    <i class="fas fa-graduation-cap me-1 text-primary"></i>Curso:
                                </label>
                                <input type="text" id="curso" name="curso" class="form-control"
                                       value="<?php echo htmlspecialchars($filtro_curso); ?>" 
                                       placeholder="Digite o nome do curso">
                            </div>

                            <div class="col-md-6 col-lg-3">
                                <label for="status" class="form-label">
                                    <i class="fas fa-info-circle me-1 text-primary"></i>Status:
                                </label>
                                <select id="status" name="status" class="form-select">
                                    <option value="">Todos os status</option>
                                    <?php foreach ($status_lista as $status): ?>
                                        <option value="<?php echo $status; ?>" <?php echo $filtro_status === $status ? 'selected' : ''; ?>>
                                            <?php echo $status; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="col-md-6 col-lg-3">
                                <label for="turno" class="form-label">
                                    <i class="fas fa-clock me-1 text-primary"></i>Turno:
                                </label>
                                <select id="turno" name="turno" class="form-select">
                                    <option value="">Todos os turnos</option>
                                    <?php foreach ($turnos_lista as $turno): ?>
                                        <option value="<?php echo $turno; ?>" <?php echo $filtro_turno === $turno ? 'selected' : ''; ?>>
                                            <?php echo $turno; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="col-12">
                                <div class="d-flex gap-2 flex-wrap">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-search me-1"></i>Filtrar
                                    </button>
                                    <?php if ($filtro_turma || $filtro_curso || $filtro_status || $filtro_turno): ?>
                                        <a href="listarTurmas.php" class="btn btn-outline-secondary">
                                            <i class="fas fa-times me-1"></i>Limpar Filtros
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="card table-card">
                    <div class="card-header sgi-bg-secondary text-white">
                        <h5 class="mb-0 fw-bold">
                            <i class="fas fa-list me-2"></i>Lista de Turmas
                            <span class="badge bg-light text-dark ms-2"><?php echo count($turmas); ?> registros</span>
                        </h5>
                    </div>
                    <div class="card-body p-0">
                        <?php if (count($turmas) > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-hover table-striped mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th><i class="fas fa-users me-1"></i>Turma</th>
                                            <th><i class="fas fa-graduation-cap me-1"></i>Curso</th>
                                            <th><i class="fas fa-calendar-start me-1"></i>Início</th>
                                            <th><i class="fas fa-calendar-end me-1"></i>Término</th>
                                            <th><i class="fas fa-clock me-1"></i>Turno</th>
                                            <th><i class="fas fa-circle me-1"></i>Status</th>
                                            <th><i class="fas fa-calendar-day me-1"></i>Vigência</th>
                                            <th><i class="fas fa-cogs me-1"></i>Ações</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($turmas as $turma): ?>
                                            <tr>
                                                <td class="fw-semibold"><?php echo htmlspecialchars($turma['nome_turma']); ?></td>
                                                <td><?php echo htmlspecialchars($turma['nome_curso']); ?></td>
                                                <td>
                                                    <span class="badge bg-light text-dark">
                                                        <?php echo date('d/m/Y', strtotime($turma['dt_inicio'])); ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <span class="badge bg-light text-dark">
                                                        <?php echo date('d/m/Y', strtotime($turma['dt_fim'])); ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <span class="badge bg-info text-white">
                                                        <?php echo htmlspecialchars($turma['nome_turno']); ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <?php 
                                                    $status_class = match($turma['nome_stturma']) {
                                                        'Ativa' => 'bg-success',
                                                        'Inativa' => 'bg-secondary',
                                                        'Em Andamento' => 'bg-primary',
                                                        'Concluída' => 'bg-warning',
                                                        default => 'bg-light text-dark'
                                                    };
                                                    ?>
                                                    <span class="badge <?php echo $status_class; ?>">
                                                        <?php echo htmlspecialchars($turma['nome_stturma']); ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <small class="text-muted">
                                                        <?php echo date('d/m/Y', strtotime($turma['dt_vigencia'])); ?>
                                                    </small>
                                                </td>
                                                <td>
                                                    <div class="btn-group btn-group-sm" role="group">
                                                        <a href="../crud_operations/editarTurma.php?id=<?php echo $turma['idturma']; ?>" 
                                                           class="btn btn-outline-primary" 
                                                           title="Editar turma">
                                                            <i class="fas fa-edit"></i>
                                                        </a>
                                                        <a href="../crud_operations/excluirTurma.php?id=<?php echo $turma['idturma']; ?>"
                                                           class="btn btn-outline-danger"
                                                           title="Excluir turma"
                                                           onclick="return confirm('Tem certeza que deseja excluir esta turma?')">
                                                            <i class="fas fa-trash"></i>
                                                        </a>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-5">
                                <i class="fas fa-users fa-3x text-muted mb-3"></i>
                                <h5 class="text-muted">
                                    <?php echo ($filtro_turma || $filtro_curso || $filtro_status || $filtro_turno) ? 
                                          'Nenhuma turma encontrada com os filtros aplicados' : 
                                          'Nenhuma turma cadastrada'; ?>
                                </h5>
                                <?php if ($filtro_turma || $filtro_curso || $filtro_status || $filtro_turno): ?>
                                    <a href="listarTurmas.php" class="btn btn-primary mt-2">
                                        <i class="fas fa-times me-1"></i>Limpar Filtros
                                    </a>
                                <?php else: ?>
                                    <a href="/sgi/views/cadastrarTurmas.php" class="btn btn-primary mt-2">
                                        <i class="fas fa-plus me-1"></i>Cadastrar Primeira Turma
                                    </a>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const rows = document.querySelectorAll('tbody tr');
            rows.forEach(row => {
                row.addEventListener('mouseenter', function() {
                    this.style.transform = 'translateX(5px)';
                    this.style.transition = 'transform 0.2s ease';
                });
                row.addEventListener('mouseleave', function() {
                    this.style.transform = 'translateX(0)';
                });
            });
        });
    </script>
</body>
</html>