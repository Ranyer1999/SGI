<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['perfil'] !== 'Coordenacao') {
    header("Location: /sgi/index.php");
    exit;
}

$host = "localhost";
$dbname = "sgi";
$username = "root";
$password = "";

$filtro_status = $_GET['status'] ?? '';
$filtro_professor = $_GET['professor'] ?? '';
$filtro_turma = $_GET['turma'] ?? '';
$filtro_componente = $_GET['componente'] ?? '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Construir a query base com filtros
    $sql = "
        SELECT 
            a.idalocacao,
            a.dt_alocacao,
            a.periodo_inicio,
            a.periodo_fim,
            p.idprofessor,
            p.nome_prof,
            t.idturma,
            t.nome_turma,
            c.nome_curso,
            comp.nome_componente,
            comp.cargahr_comp,
            s.nome_stalocacao as status_alocacao
        FROM alocacao a
        JOIN professor p ON a.idprofessor = p.idprofessor
        JOIN turma t ON a.idturma = t.idturma
        JOIN curso c ON t.idcurso = c.idcurso
        JOIN componente comp ON a.idcomponente = comp.idcomponente
        JOIN status_alocacao s ON a.idstatus_alocacao = s.idstatus_alocacao
        WHERE 1=1
    ";

    $params = [];

    if (!empty($filtro_status)) {
        $sql .= " AND s.nome_stalocacao = ?";
        $params[] = $filtro_status;
    }

    if (!empty($filtro_professor)) {
        $sql .= " AND p.nome_prof LIKE ?";
        $params[] = "%$filtro_professor%";
    }

    if (!empty($filtro_turma)) {
        $sql .= " AND t.nome_turma LIKE ?";
        $params[] = "%$filtro_turma%";
    }

    if (!empty($filtro_componente)) {
        $sql .= " AND comp.nome_componente LIKE ?";
        $params[] = "%$filtro_componente%";
    }

    $sql .= " ORDER BY a.dt_alocacao DESC, p.nome_prof";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $alocacoes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Buscar status para o filtro
    $stmtStatus = $pdo->prepare("SELECT DISTINCT nome_stalocacao FROM status_alocacao ORDER BY nome_stalocacao");
    $stmtStatus->execute();
    $status_lista = $stmtStatus->fetchAll(PDO::FETCH_COLUMN);

    // Buscar componentes para o filtro
    $stmtComponentes = $pdo->prepare("SELECT DISTINCT nome_componente FROM componente ORDER BY nome_componente");
    $stmtComponentes->execute();
    $componentes_lista = $stmtComponentes->fetchAll(PDO::FETCH_COLUMN);

} catch (PDOException $e) {
    $erro = "Erro ao carregar alocações: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="/sgi/public/img/icon.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="/sgi/public/css/style.css">
    <title>Lista de Alocações - SGI</title>
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-white bg-white shadow-sm">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">
                    <img src="/sgi/public/img/logo.png" alt="Logo SGI" class="logo-header">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="btn btn-sair" href="logout.php">
                                <i class="fas fa-sign-out-alt me-1"></i>Sair
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <main class="container-fluid mt-4">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-11">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h1 class="h3 mb-0 text-white">
                        <i class="fas fa-tasks me-2 text-white"></i>Alocações dos Docentes
                    </h1>
                    <div class="header-actions">
                        <a href="homeCoordenacao.php" class="btn btn-outline-secondary me-2 text-white border-white">
                            <i class="fas fa-arrow-left me-1 text-white"></i>Voltar
                        </a>
                        <a href="cadastrarAlocacoes.php" class="btn btn-sgi-secondary">
                            <i class="fas fa-plus me-1"></i>Nova Alocação
                        </a>
                    </div>
                </div>

                <?php if (isset($erro)): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo $erro; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <!-- Filtros -->
                <div class="card mb-4">
                    <div class="card-header bg-light">
                        <h5 class="mb-0">
                            <i class="fas fa-filter me-2"></i>Filtrar Alocações
                        </h5>
                    </div>
                    <div class="card-body">
                        <form method="get" class="row g-3">
                            <div class="col-md-3">
                                <label for="status" class="form-label">Status:</label>
                                <select id="status" name="status" class="form-select">
                                    <option value="">Todos os status</option>
                                    <?php foreach ($status_lista as $status): ?>
                                        <option value="<?php echo $status; ?>" <?php echo $filtro_status === $status ? 'selected' : ''; ?>>
                                            <?php echo $status; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="col-md-3">
                                <label for="professor" class="form-label">Professor:</label>
                                <input type="text" id="professor" name="professor" class="form-control"
                                    value="<?php echo htmlspecialchars($filtro_professor); ?>" placeholder="Nome do professor">
                            </div>

                            <div class="col-md-3">
                                <label for="turma" class="form-label">Turma:</label>
                                <input type="text" id="turma" name="turma" class="form-control" 
                                    value="<?php echo htmlspecialchars($filtro_turma); ?>" placeholder="Nome da turma">
                            </div>

                            <div class="col-md-3">
                                <label for="componente" class="form-label">Componente:</label>
                                <input type="text" id="componente" name="componente" class="form-control"
                                    value="<?php echo htmlspecialchars($filtro_componente); ?>" placeholder="Nome do componente">
                            </div>

                            <div class="col-12">
                                <button type="submit" class="btn btn-sgi-primary">
                                    <i class="fas fa-search me-1"></i>Filtrar
                                </button>
                                
                                <?php if ($filtro_status || $filtro_professor || $filtro_turma || $filtro_componente): ?>
                                    <a href="listarAlocacoes.php" class="btn btn-outline-secondary ms-2">
                                        <i class="fas fa-times me-1"></i>Limpar Filtros
                                    </a>
                                <?php endif; ?>
                            </div>
                        </form>
                    </div>
                </div>

                <?php if (count($alocacoes) > 0): ?>
                    <div class="card">
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-striped table-hover mb-0">
                                    <thead class="table-dark">
                                        <tr>
                                            <th>Professor</th>
                                            <th>Turma</th>
                                            <th>Curso</th>
                                            <th>Componente</th>
                                            <th>Carga Horária</th>
                                            <th>Data Alocação</th>
                                            <th>Período</th>
                                            <th>Status</th>
                                            <th>Ações</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($alocacoes as $alocacao): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($alocacao['nome_prof']); ?></td>
                                                <td><?php echo htmlspecialchars($alocacao['nome_turma']); ?></td>
                                                <td><?php echo htmlspecialchars($alocacao['nome_curso']); ?></td>
                                                <td><?php echo htmlspecialchars($alocacao['nome_componente']); ?></td>
                                                <td><?php echo $alocacao['cargahr_comp']; ?>h</td>
                                                <td><?php echo date('d/m/Y', strtotime($alocacao['dt_alocacao'])); ?></td>
                                                <td>
                                                    <?php echo date('d/m/Y', strtotime($alocacao['periodo_inicio'])); ?>
                                                    a
                                                    <?php echo date('d/m/Y', strtotime($alocacao['periodo_fim'])); ?>
                                                </td>
                                                <td>
                                                    <?php
                                                    $status_class = '';
                                                    if ($alocacao['status_alocacao'] === 'Ativa') {
                                                        $status_class = 'badge bg-success';
                                                    } elseif ($alocacao['status_alocacao'] === 'Encerrada') {
                                                        $status_class = 'badge bg-warning text-dark';
                                                    } elseif ($alocacao['status_alocacao'] === 'Cancelada') {
                                                        $status_class = 'badge bg-danger';
                                                    } else {
                                                        $status_class = 'badge bg-secondary';
                                                    }
                                                    ?>
                                                    <span class="<?php echo $status_class; ?>">
                                                        <?php echo htmlspecialchars($alocacao['status_alocacao']); ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <div class="btn-group" role="group">
                                                        <a href="../crud_operations/editarAlocacao.php?id=<?php echo $alocacao['idalocacao']; ?>" 
                                                           class="btn btn-sm btn-outline-primary" title="Editar">
                                                            <i class="fas fa-edit"></i>
                                                        </a>
                                                        <a href="../crud_operations/excluirAlocacao.php?id=<?php echo $alocacao['idalocacao']; ?>"
                                                           class="btn btn-sm btn-outline-danger" title="Excluir"
                                                           onclick="return confirm('Tem certeza que deseja excluir esta alocação?')">
                                                            <i class="fas fa-trash"></i>
                                                        </a>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                        <h3>Nenhuma alocação encontrada</h3>
                        <p class="text-muted">
                            <?php echo ($filtro_status || $filtro_professor || $filtro_turma || $filtro_componente) ? 'Tente ajustar os filtros.' : 'Cadastre a primeira alocação.'; ?>
                        </p>
                        <?php if (!($filtro_status || $filtro_professor || $filtro_turma || $filtro_componente)): ?>
                            <a href="cadastrarAlocacoes.php" class="btn btn-sgi-secondary mt-2">
                                <i class="fas fa-plus me-1"></i>Nova Alocação
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>